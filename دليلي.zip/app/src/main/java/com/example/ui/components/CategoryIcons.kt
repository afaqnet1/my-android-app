package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.MiscellaneousServices
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.RoomService
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.ui.graphics.vector.ImageVector

object CategoryIcons {
    fun getIcon(iconType: String): ImageVector {
        return when (iconType.lowercase()) {
            "restaurant", "restaurants" -> Icons.Default.Restaurant
            "cafe", "cafes" -> Icons.Default.LocalCafe
            "phone", "mobile_shops" -> Icons.Default.PhoneAndroid
            "phone_repair", "mobile_repair" -> Icons.Default.Build
            "computer", "computers" -> Icons.Default.Computer
            "wifi", "networks" -> Icons.Default.Wifi
            "pharmacy", "pharmacies" -> Icons.Default.LocalPharmacy
            "medical", "clinics" -> Icons.Default.MedicalServices
            "cart", "supermarkets" -> Icons.Default.ShoppingCart
            "clothes", "clothing" -> Icons.Default.Checkroom
            "shoes" -> Icons.Default.Storefront
            "electronics" -> Icons.Default.Bolt
            "car_mechanic", "car_mechanics" -> Icons.Default.DirectionsCar
            "car_parts" -> Icons.Default.SettingsSuggest
            "car_service" -> Icons.Default.Handyman
            "plumbing", "plumbing_electric" -> Icons.Default.Handyman
            "office", "service_offices" -> Icons.Default.Apartment
            "delivery" -> Icons.Default.LocalShipping
            "hotel", "hotels" -> Icons.Default.Hotel
            "sweets" -> Icons.Default.Cake
            "food_supply", "food_supplies" -> Icons.Default.Storefront
            "cleaning", "laundry" -> Icons.Default.CleaningServices
            else -> Icons.Default.Category
        }
    }
}
