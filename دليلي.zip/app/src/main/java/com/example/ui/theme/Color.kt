package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Dalili Yellow Palette
val DaliliYellowPrimary = Color(0xFFFFB800)       // Bright energetic warm yellow
val DaliliYellowDark = Color(0xFFD99B00)          // Rich golden amber
val DaliliYellowLight = Color(0xFFFFD54F)         // Soft warm yellow
val DaliliYellowContainer = Color(0xFFFFF3CD)     // Light yellow container for light theme
val DaliliYellowContainerDark = Color(0xFF332600) // Deep yellow container for dark theme
val DaliliOnYellow = Color(0xFF141208)            // High-contrast dark text on yellow

// Dark Mode Palette
val DarkBackground = Color(0xFF0F1115)           // Premium OLED charcoal black
val DarkSurface = Color(0xFF181B22)              // Elevated card surface
val DarkSurfaceVariant = Color(0xFF222631)       // Secondary surface & inputs
val DarkBorder = Color(0xFF2E3442)               // Subtle border
val DarkTextPrimary = Color(0xFFF1F5F9)          // Crisp white
val DarkTextSecondary = Color(0xFF94A3B8)        // Soft slate gray
val DarkTextMuted = Color(0xFF64748B)            // Muted gray

// Light Mode Palette
val LightBackground = Color(0xFFF8FAFC)          // Clean crisp background
val LightSurface = Color(0xFFFFFFFF)             // Pure white cards
val LightSurfaceVariant = Color(0xFFF1F5F9)      // Secondary surfaces & inputs
val LightBorder = Color(0xFFE2E8F0)              // Clean border
val LightTextPrimary = Color(0xFF0F172A)         // Deep dark slate
val LightTextSecondary = Color(0xFF475569)       // Medium slate
val LightTextMuted = Color(0xFF94A3B8)           // Light muted slate

// Functional & Semantic Colors
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenContainer = Color(0xFFDCFCE7)
val ErrorRed = Color(0xFFEF4444)
val ErrorRedContainer = Color(0xFFFEE2E2)
val InfoBlue = Color(0xFF3B82F6)
val StarGold = Color(0xFFFBBF24)
val DaliliGoldAccent = Color(0xFFF59E0B)
val DaliliDarkSurface = Color(0xFF181B22)
