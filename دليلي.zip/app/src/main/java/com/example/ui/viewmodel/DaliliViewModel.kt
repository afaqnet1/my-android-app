package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.auth.GmailAuthService
import com.example.data.auth.PendingOtp
import com.example.data.local.AppDatabase
import com.example.data.location.LocationType
import com.example.data.location.PrecisionLocationService
import com.example.data.location.ResolvedLocationResult
import com.example.data.location.VillageDirectory
import com.example.data.location.VillageInfo
import com.example.data.model.AppNotification
import com.example.data.model.AppOffer
import com.example.data.model.CategoryItem
import com.example.data.model.Place
import com.example.data.model.Review
import com.example.data.model.User
import com.example.data.repository.AdminStats
import com.example.data.repository.DaliliRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScreenTab {
    HOME,
    EXPLORE,
    MAP,
    FAVORITES,
    PROFILE,
    ADD_PLACE,
    ADMIN,
    NOTIFICATIONS
}

enum class SortFilter(val titleAr: String) {
    NEAR("الأقرب"),
    RATING("الأعلى تقييماً"),
    POPULAR("الأكثر شعبية"),
    OPEN_NOW("مفتوح الآن")
}

data class CityArea(val city: String, val areas: List<String>)

private data class FilterState(
    val query: String,
    val category: String,
    val sort: SortFilter,
    val onlyOffers: Boolean,
    val userLat: Double,
    val userLng: Double
)

class DaliliViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DaliliRepository
    private val locationService: PrecisionLocationService
    val authService: GmailAuthService

    init {
        val db = AppDatabase.getDatabase(application)
        repository = DaliliRepository(db)
        locationService = PrecisionLocationService(application)
        authService = GmailAuthService(application, repository)
    }

    // Authentication States
    val currentUser: StateFlow<User?> = repository.activeUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _isAuthDialogOpen = MutableStateFlow(false)
    val isAuthDialogOpen: StateFlow<Boolean> = _isAuthDialogOpen.asStateFlow()

    private val _isSendingOtp = MutableStateFlow(false)
    val isSendingOtp: StateFlow<Boolean> = _isSendingOtp.asStateFlow()

    private val _isVerifyingOtp = MutableStateFlow(false)
    val isVerifyingOtp: StateFlow<Boolean> = _isVerifyingOtp.asStateFlow()

    val lastSentOtp: StateFlow<PendingOtp?> = authService.lastSentOtp
    val authError: StateFlow<String?> = authService.authError

    fun openAuthDialog() {
        authService.clearError()
        _isAuthDialogOpen.value = true
    }

    fun closeAuthDialog() {
        authService.clearError()
        _isAuthDialogOpen.value = false
    }

    fun sendVerificationCode(
        email: String,
        fullName: String,
        onSuccess: (PendingOtp) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isSendingOtp.value = true
            try {
                val result = authService.sendVerificationCode(email, fullName)
                result.fold(
                    onSuccess = { pending ->
                        onSuccess(pending)
                    },
                    onFailure = { err ->
                        onError(err.message ?: "حدث خطأ أثناء إرسال الكود")
                    }
                )
            } finally {
                _isSendingOtp.value = false
            }
        }
    }

    fun verifyOtpCode(
        email: String,
        code: String,
        onSuccess: (User) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isVerifyingOtp.value = true
            try {
                val result = authService.verifyCode(email, code)
                result.fold(
                    onSuccess = { user ->
                        _isAuthDialogOpen.value = false
                        onSuccess(user)
                    },
                    onFailure = { err ->
                        onError(err.message ?: "كود التحقق غير صحيح")
                    }
                )
            } finally {
                _isVerifyingOtp.value = false
            }
        }
    }

    fun fastGoogleSignIn(
        email: String,
        fullName: String,
        onSuccess: (User) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isSendingOtp.value = true
            try {
                val result = authService.fastGoogleSignIn(email, fullName)
                result.onSuccess { user ->
                    _isAuthDialogOpen.value = false
                    onSuccess(user)
                }
            } finally {
                _isSendingOtp.value = false
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logoutUser()
        }
    }

    // Splash State
    private val _isSplashFinished = MutableStateFlow(false)
    val isSplashFinished: StateFlow<Boolean> = _isSplashFinished.asStateFlow()

    fun completeSplash() {
        _isSplashFinished.value = true
    }

    // Navigation & Screen States
    private val _currentTab = MutableStateFlow(ScreenTab.HOME)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    private val _selectedPlaceDetailId = MutableStateFlow<Long?>(null)
    val selectedPlaceDetailId: StateFlow<Long?> = _selectedPlaceDetailId.asStateFlow()

    // Dark Theme preference state
    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    // Search and Filtering
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("all")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _sortFilter = MutableStateFlow(SortFilter.NEAR)
    val sortFilter: StateFlow<SortFilter> = _sortFilter.asStateFlow()

    private val _onlyOffersFilter = MutableStateFlow(false)
    val onlyOffersFilter: StateFlow<Boolean> = _onlyOffersFilter.asStateFlow()

    // Precision Location State
    private val _userLatitude = MutableStateFlow(33.4358) // صحنايا default
    val userLatitude: StateFlow<Double> = _userLatitude.asStateFlow()

    private val _userLongitude = MutableStateFlow(36.2411)
    val userLongitude: StateFlow<Double> = _userLongitude.asStateFlow()

    private val _currentCity = MutableStateFlow("ريف دمشق")
    val currentCity: StateFlow<String> = _currentCity.asStateFlow()

    private val _currentArea = MutableStateFlow("صحنايا")
    val currentArea: StateFlow<String> = _currentArea.asStateFlow()

    private val _currentLocationType = MutableStateFlow("ضيعة")
    val currentLocationType: StateFlow<String> = _currentLocationType.asStateFlow()

    private val _isGpsActive = MutableStateFlow(true)
    val isGpsActive: StateFlow<Boolean> = _isGpsActive.asStateFlow()

    private val _isDetectingLocation = MutableStateFlow(false)
    val isDetectingLocation: StateFlow<Boolean> = _isDetectingLocation.asStateFlow()

    private val _gpsAccuracyStatus = MutableStateFlow("دقة عالية (تحديد اسم الضيعة التلقائي مفعل)")
    val gpsAccuracyStatus: StateFlow<String> = _gpsAccuracyStatus.asStateFlow()

    // City Area list generated dynamically from VillageDirectory
    val syriaCities: List<CityArea> by lazy {
        VillageDirectory.getGovernorates().map { gov ->
            val areas = VillageDirectory.getVillagesForGovernorate(gov).map { it.nameAr }
            CityArea(gov, areas)
        }
    }

    // Data streams from repository
    val categories: List<CategoryItem> = repository.getCategories()

    val allApprovedPlaces: StateFlow<List<Place>> = repository.allApprovedPlaces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingApprovalPlaces: StateFlow<List<Place>> = repository.pendingPlaces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPlacesAdmin: StateFlow<List<Place>> = repository.allPlacesAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val featuredPlaces: StateFlow<List<Place>> = repository.featuredPlaces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoritePlaces: StateFlow<List<Place>> = repository.favoritePlaces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteIds: StateFlow<List<Long>> = repository.favoriteIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeOffers: StateFlow<List<AppOffer>> = repository.activeOffers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = repository.unreadNotificationCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Filter flow combination
    private val filterStateFlow = combine(
        _searchQuery,
        _selectedCategory,
        _sortFilter,
        _onlyOffersFilter
    ) { query, category, sort, onlyOffers ->
        FilterState(
            query = query,
            category = category,
            sort = sort,
            onlyOffers = onlyOffers,
            userLat = _userLatitude.value,
            userLng = _userLongitude.value
        )
    }

    // Filtered places stream with dynamically updated real distance
    val filteredPlaces: StateFlow<List<Place>> = combine(
        allApprovedPlaces,
        filterStateFlow,
        _userLatitude,
        _userLongitude
    ) { places, filter, uLat, uLng ->
        // Recalculate distance dynamically relative to user's exact coordinates / village
        val placesWithRealDistance = places.map { place ->
            val dist = VillageDirectory.calculateDistanceKm(uLat, uLng, place.latitude, place.longitude)
            val roundedDist = Math.round(dist * 10.0) / 10.0
            place.copy(distanceKm = if (roundedDist < 0.1) 0.1 else roundedDist)
        }

        var list = placesWithRealDistance

        // Filter by search query (name, category, services, area, description)
        if (filter.query.isNotBlank()) {
            val q = filter.query.trim().lowercase()
            list = list.filter { place ->
                place.name.lowercase().contains(q) ||
                place.categoryName.lowercase().contains(q) ||
                place.services.lowercase().contains(q) ||
                place.area.lowercase().contains(q) ||
                place.city.lowercase().contains(q) ||
                place.address.lowercase().contains(q) ||
                place.description.lowercase().contains(q)
            }
        }

        // Filter by category
        if (filter.category != "all") {
            list = list.filter { it.categoryId == filter.category }
        }

        // Filter by offers
        if (filter.onlyOffers) {
            list = list.filter { !it.currentOffer.isNullOrBlank() }
        }

        // Sorting
        when (filter.sort) {
            SortFilter.NEAR -> list.sortedBy { it.distanceKm }
            SortFilter.RATING -> list.sortedByDescending { it.rating }
            SortFilter.POPULAR -> list.sortedByDescending { it.reviewCount }
            SortFilter.OPEN_NOW -> list.sortedByDescending { if (it.isOpenNow) 1 else 0 }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin Stats
    private val _adminStats = MutableStateFlow<AdminStats?>(null)
    val adminStats: StateFlow<AdminStats?> = _adminStats.asStateFlow()

    // Navigation actions
    fun setTab(tab: ScreenTab) {
        _currentTab.value = tab
        _selectedPlaceDetailId.value = null
    }

    fun navigateToPlaceDetail(placeId: Long) {
        _selectedPlaceDetailId.value = placeId
    }

    fun navigateBack() {
        if (_selectedPlaceDetailId.value != null) {
            _selectedPlaceDetailId.value = null
        } else if (_currentTab.value != ScreenTab.HOME) {
            _currentTab.value = ScreenTab.HOME
        }
    }

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    // Search and filters
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(categoryId: String) {
        _selectedCategory.value = categoryId
    }

    fun setSortFilter(filter: SortFilter) {
        _sortFilter.value = filter
    }

    fun toggleOnlyOffers() {
        _onlyOffersFilter.value = !_onlyOffersFilter.value
    }

    /**
     * Set location to specific village or custom district
     */
    fun setLocation(city: String, area: String, isGps: Boolean = false, lat: Double? = null, lng: Double? = null) {
        _currentCity.value = city
        _currentArea.value = area
        _isGpsActive.value = isGps

        if (lat != null && lng != null) {
            _userLatitude.value = lat
            _userLongitude.value = lng
        } else {
            // Lookup coordinates from VillageDirectory
            val match = VillageDirectory.allLocations.find { it.nameAr == area }
            if (match != null) {
                _userLatitude.value = match.lat
                _userLongitude.value = match.lng
                _currentLocationType.value = match.type.labelAr
            }
        }
        _gpsAccuracyStatus.value = if (isGps) "تم التحديد عبر GPS الفائق بدقة 100%" else "تم التحديد يدوياً: $area"
    }

    /**
     * Select a specific Village from the Directory
     */
    fun selectVillage(village: VillageInfo) {
        _currentCity.value = village.governorateAr
        _currentArea.value = village.nameAr
        _currentLocationType.value = village.type.labelAr
        _userLatitude.value = village.lat
        _userLongitude.value = village.lng
        _isGpsActive.value = false
        _gpsAccuracyStatus.value = "تم اختيار ${village.type.labelAr}: ${village.nameAr} (${village.governorateAr})"
    }

    /**
     * Run high-precision GPS detection with Reverse Geocoding
     */
    fun detectPrecisionGps(onComplete: ((ResolvedLocationResult) -> Unit)? = null) {
        viewModelScope.launch {
            _isDetectingLocation.value = true
            try {
                val result = locationService.getCurrentPrecisionLocation()
                _currentCity.value = result.governorate
                _currentArea.value = result.villageOrAreaName
                _userLatitude.value = result.latitude
                _userLongitude.value = result.longitude
                _isGpsActive.value = true
                _gpsAccuracyStatus.value = result.statusMessage
                _currentLocationType.value = if (result.isVillageDetected) "ضيعة / قرية" else "حي / منطقة"
                onComplete?.invoke(result)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isDetectingLocation.value = false
            }
        }
    }

    // Favorites
    fun toggleFavorite(placeId: Long) {
        viewModelScope.launch {
            val isFav = favoriteIds.value.contains(placeId)
            repository.toggleFavorite(placeId, isFav)
        }
    }

    // Place Details Stream
    fun getPlaceById(placeId: Long): Flow<Place?> {
        return repository.getPlaceById(placeId)
    }

    fun getReviewsForPlace(placeId: Long): Flow<List<Review>> {
        return repository.getReviewsForPlace(placeId)
    }

    fun addReview(placeId: Long, userName: String, rating: Int, comment: String) {
        viewModelScope.launch {
            repository.addReview(placeId, userName, rating, comment)
        }
    }

    // Business Owner Place Submission
    fun addNewPlace(place: Place) {
        viewModelScope.launch {
            repository.submitPlace(place)
        }
    }

    // Notifications
    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
        }
    }

    fun markNotificationRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    // Admin Operations
    fun approvePlace(placeId: Long) {
        viewModelScope.launch {
            repository.approvePlace(placeId)
        }
    }

    fun rejectPlace(placeId: Long) {
        viewModelScope.launch {
            repository.rejectPlace(placeId)
        }
    }

    fun deletePlace(placeId: Long) {
        viewModelScope.launch {
            repository.deletePlace(placeId)
        }
    }

    fun addNewOffer(offer: AppOffer) {
        viewModelScope.launch {
            repository.addOffer(offer)
        }
    }
}

