package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Place
import com.example.ui.components.CategoryChip
import com.example.ui.components.CategoryIcons
import com.example.ui.theme.DaliliYellowPrimary
import com.example.ui.theme.StarGold
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.DaliliViewModel
import kotlin.math.sqrt

@Composable
fun MapScreen(
    viewModel: DaliliViewModel,
    onOpenLocationDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allPlaces by viewModel.allApprovedPlaces.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val currentCity by viewModel.currentCity.collectAsStateWithLifecycle()
    val currentArea by viewModel.currentArea.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var selectedPlaceOnMap by remember { mutableStateOf<Place?>(null) }
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }

    val filteredPlaces = if (selectedCategory == "all") {
        allPlaces
    } else {
        allPlaces.filter { it.categoryId == selectedCategory }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("map_screen")
    ) {
        // Interactive Custom Stylized Vector Map Canvas
        val isDark = MaterialTheme.colorScheme.background.red < 0.5f
        val mapBgColor = if (isDark) Color(0xFF14171E) else Color(0xFFE2E8F0)
        val roadColor = if (isDark) Color(0xFF222834) else Color(0xFFCBD5E1)
        val majorRoadColor = if (isDark) Color(0xFF2D3546) else Color(0xFF94A3B8)
        val waterColor = if (isDark) Color(0xFF132030) else Color(0xFFBAE6FD)
        val parkColor = if (isDark) Color(0xFF16251C) else Color(0xFFDCFCE7)

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(filteredPlaces, zoomScale, panOffset) {
                    detectTapGestures { tapOffset ->
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        // Calculate which pin was tapped
                        var clickedPlace: Place? = null
                        filteredPlaces.forEachIndexed { index, place ->
                            val normalizedX = ((place.longitude - 36.25) / 0.08).toFloat().coerceIn(0.1f, 0.9f)
                            val normalizedY = (1f - ((place.latitude - 33.48) / 0.08).toFloat()).coerceIn(0.1f, 0.9f)

                            val pinX = (normalizedX * canvasWidth) * zoomScale + panOffset.x
                            val pinY = (normalizedY * canvasHeight) * zoomScale + panOffset.y

                            val dist = sqrt((tapOffset.x - pinX) * (tapOffset.x - pinX) + (tapOffset.y - pinY) * (tapOffset.y - pinY))
                            if (dist < 40.dp.toPx()) {
                                clickedPlace = place
                            }
                        }

                        if (clickedPlace != null) {
                            selectedPlaceOnMap = clickedPlace
                        } else {
                            selectedPlaceOnMap = null
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            // Background canvas
            drawRect(color = mapBgColor)

            // Draw Decorative River / Park features
            val riverPath = Path().apply {
                moveTo(0f, height * 0.35f)
                cubicTo(width * 0.3f, height * 0.38f, width * 0.6f, height * 0.3f, width, height * 0.42f)
                lineTo(width, height * 0.48f)
                cubicTo(width * 0.6f, height * 0.36f, width * 0.3f, height * 0.44f, 0f, height * 0.41f)
                close()
            }
            drawPath(riverPath, waterColor)

            // Park areas
            drawCircle(parkColor, radius = width * 0.18f, center = Offset(width * 0.25f, height * 0.65f))
            drawCircle(parkColor, radius = width * 0.12f, center = Offset(width * 0.78f, height * 0.22f))

            // Road grid
            val gridCount = 9
            for (i in 0..gridCount) {
                val y = height * (i.toFloat() / gridCount)
                drawLine(
                    color = roadColor,
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 3.dp.toPx()
                )
            }
            for (i in 0..gridCount) {
                val x = width * (i.toFloat() / gridCount)
                drawLine(
                    color = roadColor,
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 3.dp.toPx()
                )
            }

            // Major Highways
            drawLine(
                color = majorRoadColor,
                start = Offset(0f, height * 0.55f),
                end = Offset(width, height * 0.55f),
                strokeWidth = 8.dp.toPx()
            )
            drawLine(
                color = majorRoadColor,
                start = Offset(width * 0.5f, 0f),
                end = Offset(width * 0.5f, height),
                strokeWidth = 8.dp.toPx()
            )

            // User Current Location Pulse
            val userLocX = width * 0.52f
            val userLocY = height * 0.54f
            drawCircle(
                color = DaliliYellowPrimary.copy(alpha = 0.25f),
                radius = 24.dp.toPx(),
                center = Offset(userLocX, userLocY)
            )
            drawCircle(
                color = DaliliYellowPrimary,
                radius = 7.dp.toPx(),
                center = Offset(userLocX, userLocY)
            )
            drawCircle(
                color = Color.White,
                radius = 3.dp.toPx(),
                center = Offset(userLocX, userLocY)
            )

            // Draw Place Pin Markers
            filteredPlaces.forEachIndexed { index, place ->
                val normalizedX = ((place.longitude - 36.25) / 0.08).toFloat().coerceIn(0.1f, 0.9f)
                val normalizedY = (1f - ((place.latitude - 33.48) / 0.08).toFloat()).coerceIn(0.1f, 0.9f)

                val pinX = (normalizedX * width) * zoomScale + panOffset.x
                val pinY = (normalizedY * height) * zoomScale + panOffset.y

                val isSelected = selectedPlaceOnMap?.id == place.id

                // Pin Shadow / Halo
                drawCircle(
                    color = if (isSelected) DaliliYellowPrimary.copy(alpha = 0.4f) else Color.Black.copy(alpha = 0.25f),
                    radius = if (isSelected) 22.dp.toPx() else 14.dp.toPx(),
                    center = Offset(pinX, pinY)
                )

                // Pin Outer Circle
                drawCircle(
                    color = if (isSelected) DaliliYellowPrimary else Color(0xFF1E222B),
                    radius = if (isSelected) 16.dp.toPx() else 12.dp.toPx(),
                    center = Offset(pinX, pinY)
                )

                // Pin Inner Circle / Dot
                drawCircle(
                    color = if (isSelected) Color(0xFF141208) else DaliliYellowPrimary,
                    radius = if (isSelected) 7.dp.toPx() else 5.dp.toPx(),
                    center = Offset(pinX, pinY)
                )
            }
        }

        // Top Control Overlay: Category Filter Chips & Location Switcher
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(top = 12.dp)
        ) {
            // Location Bar Pill
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable(onClick = onOpenLocationDialog)
                        .testTag("map_location_dialog_button"),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    tonalElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = DaliliYellowPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "خريطة: $currentCity - $currentArea",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "(تغيير)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = DaliliYellowPrimary,
                                fontSize = 10.sp
                            )
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                    tonalElevation = 4.dp
                ) {
                    Text(
                        text = "${filteredPlaces.size} موقع",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = DaliliYellowPrimary
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Chips Row
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(viewModel.categories) { category ->
                    CategoryChip(
                        category = category,
                        isSelected = category.id == selectedCategory,
                        onClick = { viewModel.setSelectedCategory(category.id) }
                    )
                }
            }
        }

        // Map Control Floating Buttons (Center GPS, Zoom In, Zoom Out)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .clickable { zoomScale = (zoomScale * 1.2f).coerceAtMost(2.5f) },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "تكبير",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .clickable { zoomScale = (zoomScale / 1.2f).coerceAtLeast(0.7f) },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "تصغير",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .clickable {
                        panOffset = Offset.Zero
                        zoomScale = 1f
                    }
                    .testTag("map_recenter_button"),
                shape = CircleShape,
                color = DaliliYellowPrimary,
                tonalElevation = 4.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.MyLocation,
                        contentDescription = "إعادة التمركز",
                        tint = Color(0xFF141208),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Bottom Selected Place Card (Slide up preview)
        AnimatedVisibility(
            visible = selectedPlaceOnMap != null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 90.dp, start = 16.dp, end = 16.dp),
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            val place = selectedPlaceOnMap
            if (place != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("map_place_preview_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, DaliliYellowPrimary.copy(alpha = 0.6f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(DaliliYellowPrimary.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = CategoryIcons.getIcon(place.categoryId),
                                        contentDescription = null,
                                        tint = DaliliYellowPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = place.name,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${place.categoryName} • ${place.area}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }

                            IconButton(
                                onClick = { selectedPlaceOnMap = null },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = StarGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${String.format(java.util.Locale.US, "%.1f", place.rating)} (${place.reviewCount})",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "المسافة: ${String.format(java.util.Locale.US, "%.1f", place.distanceKm)} كم",
                                    style = MaterialTheme.typography.labelSmall.copy(color = DaliliYellowPrimary)
                                )
                            }

                            Text(
                                text = if (place.isOpenNow) "مفتوح الآن" else "مغلق",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (place.isOpenNow) SuccessGreen else MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Action Buttons in Bottom Preview
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.navigateToPlaceDetail(place.id) },
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(38.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = DaliliYellowPrimary,
                                    contentColor = Color(0xFF141208)
                                )
                            ) {
                                Text(
                                    text = "عرض التفاصيل الكاملة",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    val uri = Uri.parse("geo:${place.latitude},${place.longitude}?q=${Uri.encode(place.name)}")
                                    val intent = Intent(Intent.ACTION_VIEW, uri)
                                    context.startActivity(intent)
                                },
                                modifier = Modifier
                                    .weight(0.9f)
                                    .height(38.dp),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, DaliliYellowPrimary.copy(alpha = 0.6f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Directions,
                                    contentDescription = null,
                                    tint = DaliliYellowPrimary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "الاتجاهات",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = DaliliYellowPrimary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
