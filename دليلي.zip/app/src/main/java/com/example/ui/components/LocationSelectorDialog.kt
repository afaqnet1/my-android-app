package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.location.LocationType
import com.example.data.location.VillageDirectory
import com.example.data.location.VillageInfo
import com.example.ui.theme.DaliliYellowDark
import com.example.ui.theme.DaliliYellowPrimary
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LocationSelectorDialog(
    currentCity: String,
    currentArea: String,
    isGpsActive: Boolean,
    isDetectingLocation: Boolean,
    gpsAccuracyStatus: String,
    onDetectGps: () -> Unit,
    onSelectVillage: (VillageInfo) -> Unit,
    onSelectCustomLocation: (city: String, area: String) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedGovernorate by remember { mutableStateOf(currentCity.ifBlank { "ريف دمشق" }) }
    var showCustomInput by remember { mutableStateOf(false) }
    var customVillageName by remember { mutableStateOf("") }
    var showMapPicker by remember { mutableStateOf(false) }

    // Map pin state for Syrian map bounds
    var pinLat by remember { mutableDoubleStateOf(33.4358) }
    var pinLng by remember { mutableDoubleStateOf(36.2411) }

    val governorates = remember { VillageDirectory.getGovernorates() }
    val filteredVillages = remember(searchQuery, selectedGovernorate) {
        if (searchQuery.isNotBlank()) {
            VillageDirectory.searchLocations(searchQuery)
        } else {
            VillageDirectory.getVillagesForGovernorate(selectedGovernorate)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(28.dp))
                .testTag("location_selector_dialog"),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.5.dp, DaliliYellowPrimary.copy(alpha = 0.5f)),
            tonalElevation = 10.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Luxury Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(DaliliYellowPrimary, DaliliYellowDark)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GpsFixed,
                                contentDescription = null,
                                tint = Color(0xFF141208),
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = "تحديد موقعك والضيعة بدقة",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 16.sp
                                )
                            )
                            Text(
                                text = "كشف فوري لاسم الضيعة والقرية والحي بدقة فائقة",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = DaliliYellowPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // GPS Ultra Precision Trigger Card
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .clickable(enabled = !isDetectingLocation) { onDetectGps() }
                        .testTag("auto_gps_location_button"),
                    shape = RoundedCornerShape(18.dp),
                    color = DaliliYellowPrimary.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, DaliliYellowPrimary.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(DaliliYellowPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDetectingLocation) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = Color(0xFF141208),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.MyLocation,
                                        contentDescription = null,
                                        tint = Color(0xFF141208),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = if (isDetectingLocation) "جاري تحديد الضيعة بدقة عبر الأقمار الصناعية..." else "تحديد موقعي الدقيق عبر GPS",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 13.sp
                                    )
                                )
                                Text(
                                    text = gpsAccuracyStatus,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isGpsActive) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    maxLines = 1
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DaliliYellowPrimary,
                            contentColor = Color(0xFF141208)
                        ) {
                            Text(
                                text = "فحص دقيق",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar for instant village / town finding
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "ابحث عن اسم ضيعتك، قريتك، بلدتك أو حيك...",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp
                            )
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = DaliliYellowPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "مسح",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DaliliYellowPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("village_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Mode Selectors (Governorates vs Interactive Map Picker vs Custom Village)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                showMapPicker = !showMapPicker
                                showCustomInput = false
                            },
                        shape = RoundedCornerShape(10.dp),
                        color = if (showMapPicker) DaliliYellowPrimary else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (showMapPicker) DaliliYellowPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 7.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Map,
                                contentDescription = null,
                                tint = if (showMapPicker) Color(0xFF141208) else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "دبوس الخريطة",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (showMapPicker) Color(0xFF141208) else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                showCustomInput = !showCustomInput
                                showMapPicker = false
                            },
                        shape = RoundedCornerShape(10.dp),
                        color = if (showCustomInput) DaliliYellowPrimary else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (showCustomInput) DaliliYellowPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 7.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddLocationAlt,
                                contentDescription = null,
                                tint = if (showCustomInput) Color(0xFF141208) else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "كتابة اسم ضيعة",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (showCustomInput) Color(0xFF141208) else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }

                // Interactive Mini Map Pin Picker
                AnimatedVisibility(visible = showMapPicker, enter = fadeIn(), exit = fadeOut()) {
                    Column(modifier = Modifier.padding(top = 10.dp)) {
                        Text(
                            text = "انقر على الخريطة لتحديد نقطة ضيعتك بدقة:",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = DaliliYellowPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF161A22))
                                .border(1.dp, DaliliYellowPrimary.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                                .pointerInput(Unit) {
                                    detectTapGestures { offset ->
                                        // Map tap coordinates into Lat/Lng range around Syria
                                        val normX = offset.x / size.width
                                        val normY = offset.y / size.height
                                        pinLat = 36.5 - (normY * 4.0)
                                        pinLng = 35.5 + (normX * 6.5)
                                    }
                                }
                        ) {
                            Canvas(modifier = Modifier.matchParentSize()) {
                                // Draw grid lines
                                for (i in 1..4) {
                                    drawLine(
                                        color = Color(0xFF242A36),
                                        start = Offset(0f, size.height * (i / 5f)),
                                        end = Offset(size.width, size.height * (i / 5f)),
                                        strokeWidth = 1f
                                    )
                                    drawLine(
                                        color = Color(0xFF242A36),
                                        start = Offset(size.width * (i / 5f), 0f),
                                        end = Offset(size.width * (i / 5f), size.height),
                                        strokeWidth = 1f
                                    )
                                }
                            }

                            val (nearestFromPin, distKm) = remember(pinLat, pinLng) {
                                VillageDirectory.findNearestVillage(pinLat, pinLng)
                            }

                            // Pin indicator
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Place,
                                    contentDescription = null,
                                    tint = DaliliYellowPrimary,
                                    modifier = Modifier.size(30.dp)
                                )
                            }

                            // Bottom info badge inside map
                            Surface(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(6.dp),
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF0F1115).copy(alpha = 0.9f),
                                border = BorderStroke(1.dp, DaliliYellowPrimary.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "أقرب ضيعة: ${nearestFromPin.nameAr} (${nearestFromPin.governorateAr})",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = DaliliYellowPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Button(
                                        onClick = {
                                            onSelectVillage(nearestFromPin)
                                            onDismiss()
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = DaliliYellowPrimary,
                                            contentColor = Color(0xFF141208)
                                        ),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(24.dp)
                                    ) {
                                        Text("اختيار", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Custom Village Input
                AnimatedVisibility(visible = showCustomInput, enter = fadeIn(), exit = fadeOut()) {
                    Column(modifier = Modifier.padding(top = 10.dp)) {
                        Text(
                            text = "اكتب اسم قريتك / ضيعتك بدقة:",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = DaliliYellowPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = customVillageName,
                                onValueChange = { customVillageName = it },
                                placeholder = { Text("مثال: ضيعة عرنة، مزرعة الروضة...", fontSize = 11.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (customVillageName.isNotBlank()) {
                                        onSelectCustomLocation(selectedGovernorate, customVillageName.trim())
                                        onDismiss()
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = DaliliYellowPrimary,
                                    contentColor = Color(0xFF141208)
                                ),
                                enabled = customVillageName.isNotBlank()
                            ) {
                                Text("حفظ", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Governorate Selector Tabs if not searching
                if (searchQuery.isEmpty() && !showMapPicker && !showCustomInput) {
                    Text(
                        text = "المحافظة:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(governorates) { gov ->
                            val isGovSelected = gov == selectedGovernorate
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { selectedGovernorate = gov },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isGovSelected) DaliliYellowPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(
                                    1.dp,
                                    if (isGovSelected) DaliliYellowPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                )
                            ) {
                                Text(
                                    text = gov,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isGovSelected) FontWeight.ExtraBold else FontWeight.Normal,
                                        color = if (isGovSelected) Color(0xFF141208) else MaterialTheme.colorScheme.onSurface,
                                        fontSize = 11.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Village / District / Town Chips List
                Text(
                    text = if (searchQuery.isNotBlank()) "نتائج البحث في الضيع والقرى (${filteredVillages.size}):" else "الضيع، البلدات، والقرى في $selectedGovernorate:",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredVillages) { village ->
                        val isSelected = village.nameAr == currentArea
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    onSelectVillage(village)
                                    onDismiss()
                                },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) DaliliYellowPrimary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) DaliliYellowPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Default.Check else Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = if (isSelected) DaliliYellowPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = village.nameAr,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                                                color = if (isSelected) DaliliYellowPrimary else MaterialTheme.colorScheme.onSurface,
                                                fontSize = 13.sp
                                            )
                                        )
                                        Text(
                                            text = "${village.governorateAr} • ${village.districtAr}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isSelected) DaliliYellowPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(0.5.dp, DaliliYellowPrimary.copy(alpha = 0.3f))
                                ) {
                                    Text(
                                        text = village.type.labelAr,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp,
                                            color = if (isSelected) Color(0xFF141208) else MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
