package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.AppOffer
import com.example.data.model.CategoryItem
import com.example.data.model.Favorite
import com.example.data.model.Place
import com.example.data.model.Review
import com.example.data.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DaliliRepository(private val database: AppDatabase) {

    private val placeDao = database.placeDao()
    private val reviewDao = database.reviewDao()
    private val favoriteDao = database.favoriteDao()
    private val notificationDao = database.notificationDao()
    private val offerDao = database.offerDao()
    private val userDao = database.userDao()

    val allApprovedPlaces: Flow<List<Place>> = placeDao.getAllApprovedPlaces()
    val allPlacesAdmin: Flow<List<Place>> = placeDao.getAllPlacesAdmin()
    val pendingPlaces: Flow<List<Place>> = placeDao.getPendingPlaces()
    val featuredPlaces: Flow<List<Place>> = placeDao.getFeaturedPlaces()
    val placesWithOffers: Flow<List<Place>> = placeDao.getPlacesWithOffers()
    val favoriteIds: Flow<List<Long>> = favoriteDao.getAllFavoriteIds()
    val allNotifications: Flow<List<AppNotification>> = notificationDao.getAllNotifications()
    val unreadNotificationCount: Flow<Int> = notificationDao.getUnreadCount()
    val activeOffers: Flow<List<AppOffer>> = offerDao.getActiveOffers()
    val activeUser: Flow<User?> = userDao.getActiveUser()

    val favoritePlaces: Flow<List<Place>> = combine(allApprovedPlaces, favoriteIds) { places, ids ->
        places.filter { it.id in ids }
    }

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedInitialDataIfNeeded()
        }
    }

    fun getPlaceById(id: Long): Flow<Place?> = placeDao.getPlaceById(id)

    suspend fun getPlaceByIdDirect(id: Long): Place? = placeDao.getPlaceByIdDirect(id)

    fun getReviewsForPlace(placeId: Long): Flow<List<Review>> = reviewDao.getReviewsForPlace(placeId)

    fun getAllReviews(): Flow<List<Review>> = reviewDao.getAllReviews()

    fun isFavorite(placeId: Long): Flow<Boolean> = favoriteDao.isFavorite(placeId)

    suspend fun toggleFavorite(placeId: Long, isCurrentlyFav: Boolean) = withContext(Dispatchers.IO) {
        if (isCurrentlyFav) {
            favoriteDao.removeFavorite(placeId)
        } else {
            favoriteDao.addFavorite(Favorite(placeId = placeId))
        }
    }

    suspend fun submitPlace(place: Place): Long = withContext(Dispatchers.IO) {
        val id = placeDao.insertPlace(place)
        // Add a notification for admin & user
        notificationDao.insertNotification(
            AppNotification(
                title = "تم استلام طلب إضافة مكان",
                message = "طلب إضافة «${place.name}» قيد المراجعة من قبل الإدارة وسيتم تفعيله قريباً.",
                type = "PLACE",
                placeId = id
            )
        )
        id
    }

    suspend fun approvePlace(placeId: Long) = withContext(Dispatchers.IO) {
        placeDao.updatePlaceStatus(placeId, "APPROVED")
        val place = placeDao.getPlaceByIdDirect(placeId)
        if (place != null) {
            notificationDao.insertNotification(
                AppNotification(
                    title = "مكان جديد متاح الآن",
                    message = "تمت إضافة «${place.name}» في تصنيف ${place.categoryName} بنجاح!",
                    type = "PLACE",
                    placeId = placeId
                )
            )
        }
    }

    suspend fun rejectPlace(placeId: Long) = withContext(Dispatchers.IO) {
        placeDao.updatePlaceStatus(placeId, "REJECTED")
    }

    suspend fun deletePlace(placeId: Long) = withContext(Dispatchers.IO) {
        placeDao.deletePlace(placeId)
        favoriteDao.removeFavorite(placeId)
    }

    suspend fun updatePlace(place: Place) = withContext(Dispatchers.IO) {
        placeDao.updatePlace(place)
    }

    suspend fun addReview(placeId: Long, userName: String, rating: Int, comment: String): Long = withContext(Dispatchers.IO) {
        val review = Review(
            placeId = placeId,
            userName = userName.ifBlank { "مستخدم دليلي" },
            rating = rating,
            comment = comment,
            dateText = "الآن"
        )
        val id = reviewDao.insertReview(review)
        
        // Recalculate rating
        val place = placeDao.getPlaceByIdDirect(placeId)
        if (place != null) {
            val newCount = place.reviewCount + 1
            val newRating = ((place.rating * place.reviewCount) + rating) / newCount
            placeDao.updatePlaceRating(placeId, String.format(java.util.Locale.US, "%.1f", newRating).toFloat(), newCount)
        }
        id
    }

    suspend fun deleteReview(reviewId: Long) = withContext(Dispatchers.IO) {
        reviewDao.deleteReview(reviewId)
    }

    suspend fun markNotificationAsRead(id: Long) = withContext(Dispatchers.IO) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsAsRead() = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead()
    }

    suspend fun addNotification(title: String, message: String, type: String) = withContext(Dispatchers.IO) {
        notificationDao.insertNotification(
            AppNotification(
                title = title,
                message = message,
                type = type
            )
        )
    }

    suspend fun addOffer(offer: AppOffer) = withContext(Dispatchers.IO) {
        offerDao.insertOffer(offer)
        notificationDao.insertNotification(
            AppNotification(
                title = "عرض مميز جديد: ${offer.discountText}",
                message = "${offer.placeName}: ${offer.title} - ${offer.description}",
                type = "OFFER",
                placeId = offer.placeId
            )
        )
    }

    suspend fun getUserByEmail(email: String): User? = withContext(Dispatchers.IO) {
        userDao.getUserByEmailDirect(email.trim().lowercase())
    }

    suspend fun saveUser(user: User) = withContext(Dispatchers.IO) {
        userDao.insertOrUpdateUser(user.copy(email = user.email.trim().lowercase()))
    }

    suspend fun logoutUser() = withContext(Dispatchers.IO) {
        userDao.deleteAllUsers()
    }

    suspend fun deleteOffer(id: Long) = withContext(Dispatchers.IO) {
        offerDao.deleteOffer(id)
    }

    suspend fun getAdminStats(): AdminStats = withContext(Dispatchers.IO) {
        val totalPlaces = placeDao.getTotalCount()
        val approvedPlaces = placeDao.getApprovedCount()
        val pendingPlaces = placeDao.getPendingCount()
        val totalReviews = reviewDao.getTotalCount()
        AdminStats(
            totalUsers = 1420 + totalReviews * 3,
            totalPlaces = totalPlaces,
            approvedPlaces = approvedPlaces,
            pendingPlaces = pendingPlaces,
            totalReviews = totalReviews,
            totalVisits = 28540 + totalPlaces * 120
        )
    }

    fun getCategories(): List<CategoryItem> = listOf(
        CategoryItem("all", "الكل", "grid", description = "جميع التصنيفات والخدمات"),
        CategoryItem("restaurants", "مطاعم", "restaurant", description = "وجبات سريعة، مأكولات شرقية وغربية، مشاوي"),
        CategoryItem("cafes", "مقاهي", "cafe", description = "قهوة مختصة، شاي، جلسات عائلية وشبابية"),
        CategoryItem("mobile_shops", "محلات موبايلات", "phone", description = "بيع هواتف ذكية، إكسسوارات، بطاقات شحن"),
        CategoryItem("mobile_repair", "صيانة موبايلات", "phone_repair", description = "تبديل شاشات، فك قفل، صيانة سوفت وير وهاردوير"),
        CategoryItem("computers", "كمبيوتر ولابتوب", "computer", description = "أجهزة مكتبية، لابتوبات، قطع غيار وصيانة"),
        CategoryItem("networks", "شبكات وإنترنت", "wifi", description = "راوترات، تمديد كوابل فايبر، دعم شبكات"),
        CategoryItem("pharmacies", "صيدليات", "pharmacy", description = "أدوية، مستلزمات طبية، مناوبة ليلية"),
        CategoryItem("clinics", "عيادات", "medical", description = "أطباء اختصاص، مراكز أسنان، تحاليل مخبرية"),
        CategoryItem("supermarkets", "سوبر ماركت", "cart", description = "مواد غذائية، منتجات استهلاكية، منظفات"),
        CategoryItem("clothing", "ملابس", "clothes", description = "أزياء رجالية، نسائية، وأطفال وماركات محلية"),
        CategoryItem("shoes", "أحذية", "shoes", description = "أحذية رياضية، رسمية، وحقائب جلدية"),
        CategoryItem("electronics", "كهربائيات", "electronics", description = "شاشات، أدوات منزلية، غسالات وبرادات"),
        CategoryItem("car_mechanics", "ميكانيك سيارات", "car_mechanic", description = "فحص كمبيوتر، دوزان، صيانة محركات"),
        CategoryItem("car_parts", "قطع سيارات", "car_parts", description = "قطع غيار أصلية وتجارية لجميع السيارات"),
        CategoryItem("car_service", "صيانة سيارات", "car_service", description = "غسيل، تغيير زيت، كهرباء وإلكترونيات سيارات"),
        CategoryItem("plumbing_electric", "كهرباء وسباكة", "plumbing", description = "صيانة منزلية، تمديدات صحية، طاقة شمسية"),
        CategoryItem("service_offices", "مكاتب خدمات", "office", description = "ترجمة محلفة، معاملات عقارية، استشارات"),
        CategoryItem("delivery", "توصيل وشحن", "delivery", description = "شحن طرود، شركات توصيل سريع داخلي وخارجي"),
        CategoryItem("hotels", "فنادق", "hotel", description = "فنادق سياحية، أجنحة فندقية، شقق مفروشة"),
        CategoryItem("sweets", "محلات حلويات", "sweets", description = "حلويات عربية، غربية، بقلاوة وكيك مناسبات"),
        CategoryItem("food_supplies", "مواد غذائية", "food_supply", description = "تجارة جملة، أجبان وألبان، بهارات ومحمصة"),
        CategoryItem("laundry", "مغاسل وتنظيف", "cleaning", description = "غسيل وكوي ملابس، تنظيف سجاد ومفروشات")
    )

    private suspend fun seedInitialDataIfNeeded() {
        val count = placeDao.getTotalCount()
        if (count > 0) return

        val placesList = listOf(
            Place(
                name = "مطعم الشرق الدمشقي",
                categoryId = "restaurants",
                categoryName = "مطاعم",
                rating = 4.9f,
                reviewCount = 128,
                address = "دمشق - المزة - شارع الفيلات الشرقية",
                area = "المزة",
                city = "دمشق",
                distanceKm = 0.8,
                workingHours = "11:00 ص - 01:30 ص",
                phone = "+963116123456",
                whatsapp = "+963944112233",
                latitude = 33.5138,
                longitude = 36.2765,
                description = "مطعم راقٍ يقدم أشهى المأكولات الشرقية والمشاوي الشامية مع إطلالة مميزة وخدمة استثنائية وجلسات عائلية مريحة.",
                services = "وجبات سريعة, مشاوي شامية, مأكولات غربية, خدمة التوصيل, جلسات عائلية, إنترنت مجاني, مواقف سيارات",
                currentOffer = "خصم 20% على المشاوي العائلية",
                isFeatured = true,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "شكري العيسى"
            ),
            Place(
                name = "كافيه ومقهى الرواق الفاخر",
                categoryId = "cafes",
                categoryName = "مقاهي",
                rating = 4.8f,
                reviewCount = 94,
                address = "دمشق - أبورمانة - مقابل الحديقة العامة",
                area = "أبورمانة",
                city = "دمشق",
                distanceKm = 1.2,
                workingHours = "08:00 ص - 12:00 م",
                phone = "+963113344556",
                whatsapp = "+963955223344",
                latitude = 33.5220,
                longitude = 36.2840,
                description = "مقهى عصري متخصص في تقديم أجود أنواع القهوة المختصة، والحلويات الفرنسية، وجلسات عمل هادئة مع شبكة إنترنت فائقة السرعة.",
                services = "قهوة مختصة, فطور صباحي, عصائر طبيعية, وايفاي سريع, مساحة عمل هادئة, جلسات خارجية",
                currentOffer = "قهوة + حلى مجاناً مع وجبة الفطور",
                isFeatured = true,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "إدارة دليلي"
            ),
            Place(
                name = "مركز سمارت فون برو",
                categoryId = "mobile_repair",
                categoryName = "صيانة موبايلات",
                rating = 4.7f,
                reviewCount = 67,
                address = "دمشق - البرامكة - مجمع الصالحية التجاري",
                area = "البرامكة",
                city = "دمشق",
                distanceKm = 1.5,
                workingHours = "09:30 ص - 09:30 م",
                phone = "+963112211990",
                whatsapp = "+963988776655",
                latitude = 33.5090,
                longitude = 36.2920,
                description = "مركز معتمد لصيانة كافة أجهزة الآيفون والأندرويد، تبديل شاشات أصلية، صيانة بوردات مايكروسكوب، وفك حمايات وبرمجة فورية مع ضمان حقيقي.",
                services = "تبديل شاشات فورياً, صيانة بورد, سوفت وير وبرمجة, قطع أصلية مع كفالة, فحص مجاني للجهاز",
                currentOffer = "فحص وصيانة سوفت وير مجاناً",
                isFeatured = false,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "م. أحمد الشام"
            ),
            Place(
                name = "تيك ماستر للكمبيوتر واللابتوب",
                categoryId = "computers",
                categoryName = "كمبيوتر ولابتوب",
                rating = 4.9f,
                reviewCount = 82,
                address = "دمشق - البحصة - سوق الكمبيوتر",
                area = "البحصة",
                city = "دمشق",
                distanceKm = 2.1,
                workingHours = "10:00 ص - 08:30 م",
                phone = "+963112338877",
                whatsapp = "+963933445566",
                latitude = 33.5185,
                longitude = 36.2980,
                description = "أكبر تشكيلة لابتوبات قيمنق ومكتبية جديدة ومستعملة مع كفالة، تجميعات بي سي احترافية، قطع غيار وهاردات SSD وشاشات عالية الدقة.",
                services = "بيع لابتوبات, تجميع كمبيوتر, ترقية قطع ورامات, صيانة لابتوبات معقدة, تنصيب برامج وأنظمة",
                currentOffer = "حقيبة وماوس مجاناً مع كل لابتوب",
                isFeatured = true,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "إدارة دليلي"
            ),
            Place(
                name = "صيدلية النور الحديثة",
                categoryId = "pharmacies",
                categoryName = "صيدليات",
                rating = 4.9f,
                reviewCount = 110,
                address = "دمشق - كفرسوسة - قرب الشام سيتي سنتر",
                area = "كفرسوسة",
                city = "دمشق",
                distanceKm = 0.5,
                workingHours = "مفتوح 24 ساعة (مناوبة دائمة)",
                phone = "+963112115544",
                whatsapp = "+963966554433",
                latitude = 33.4980,
                longitude = 36.2750,
                description = "صيدلية مناوبة على مدار الساعة، توفر جميع الأدوية الوطنية والمستوردة، حليب الأطفال، منتجات العناية بالبشرة، وأجهزة قياس الضغط والسكر.",
                services = "خدمة 24 ساعة, قياس ضغط وسكر مجاناً, استشارات صيدلانية, تأمين أدوية نادرة, توصيل منزلي",
                currentOffer = null,
                isFeatured = false,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "د. نور الدين"
            ),
            Place(
                name = "عيادات الشام التخصصية لطب الأسنان",
                categoryId = "clinics",
                categoryName = "عيادات",
                rating = 4.8f,
                reviewCount = 53,
                address = "دمشق - المزرعة - ساحة الشهبندر",
                area = "المزرعة",
                city = "دمشق",
                distanceKm = 2.4,
                workingHours = "10:00 ص - 08:00 م (الجمعة مغلق)",
                phone = "+963114433221",
                whatsapp = "+963944889900",
                latitude = 33.5280,
                longitude = 36.2950,
                description = "مركز تخصصي متكامل لطب وجراحة وتجميل الأسنان، زراعة الأسنان الرقمية، تقويم شفاف، وتبييض الأسنان بأحدث تقنيات الليزر العالمية.",
                services = "زراعة أسنان رقمية, هوليوود سمايل, تقويم شفاف, معالجة عصب بدون ألم, تصوير بانوراما",
                currentOffer = "خصم 30% على تبييض الأسنان بالليزر",
                isFeatured = true,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "د. وسيم حبيب"
            ),
            Place(
                name = "هايبر ماركت المدينة",
                categoryId = "supermarkets",
                categoryName = "سوبر ماركت",
                rating = 4.6f,
                reviewCount = 145,
                address = "دمشق - مشروع دمر - الجزيرة الأولى",
                area = "مشروع دمر",
                city = "دمشق",
                distanceKm = 3.8,
                workingHours = "08:00 ص - 01:00 ص",
                phone = "+963113119988",
                whatsapp = "+963955667788",
                latitude = 33.5350,
                longitude = 36.2300,
                description = "هايبر ماركت شامل يلبي كافة احتياجات العائلة من المواد الغذائية الطازجة، الخضار والفواكه، اللحوم، الأجبان، والمنظفات بأسعار منافسة.",
                services = "تسوق شامل, قسم لحوم طازجة, مخبوزات يومية, خدمة توصيل سريع, دفع إلكتروني",
                currentOffer = "عروض نهاية الأسبوع على المنظفات والمواد الغذائية",
                isFeatured = false,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "إدارة دليلي"
            ),
            Place(
                name = "مركز النجم لصيانة وميكانيك السيارات",
                categoryId = "car_mechanics",
                categoryName = "ميكانيك سيارات",
                rating = 4.8f,
                reviewCount = 42,
                address = "دمشق - حوش بلاس - المنطقة الصناعية",
                area = "حوش بلاس",
                city = "دمشق",
                distanceKm = 5.2,
                workingHours = "08:30 ص - 07:00 م",
                phone = "+963118822334",
                whatsapp = "+963933990011",
                latitude = 33.4500,
                longitude = 36.3100,
                description = "كراج احترافي مجهز بأحدث أجهزة فحص الأعطال بالكمبيوتر لجميع السيارات الحديثة والهايبرد والكهربائية، فحص دوزان، وصيانة محركات وجيربوكس.",
                services = "فحص كمبيوتر شامل, صيانة محركات, فحص وبرمجة سيارات هايبرد, صيانة فرامل ودوزان, صيانة تكييف",
                currentOffer = "فحص كمبيوتر مجاني مع كل غيار زيت",
                isFeatured = true,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "المعلم فادي"
            ),
            Place(
                name = "مؤسسة الأمان للكهرباء والطاقة البديلة",
                categoryId = "plumbing_electric",
                categoryName = "كهرباء وسباكة",
                rating = 4.7f,
                reviewCount = 39,
                address = "دمشق - شارع بغداد - نزلة القصور",
                area = "شارع بغداد",
                city = "دمشق",
                distanceKm = 1.9,
                workingHours = "09:00 ص - 09:00 م",
                phone = "+963114455667",
                whatsapp = "+963944332211",
                latitude = 33.5240,
                longitude = 36.3050,
                description = "متخصصون في تركيب وصيانة منظومات الطاقة الشمسية والإنفرتر والبطاريات الليثيوم، تمديدات كهربائية منزلية وصناعية، وصيانة سباكة ومضخات.",
                services = "تركيب طاقة شمسية, إنفرترات وبطاريات ليثيوم, تمديدات كهربائية معتمدة, تمديدات صحية, صيانة طوارئ منزلية",
                currentOffer = "كفالة شاملة 3 سنوات على بطاريات الليثيوم",
                isFeatured = false,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "م. خالد المهندس"
            ),
            Place(
                name = "حلويات قصر الشام الملكية",
                categoryId = "sweets",
                categoryName = "محلات حلويات",
                rating = 4.9f,
                reviewCount = 180,
                address = "دمشق - الميدان - جزماتية",
                area = "الميدان",
                city = "دمشق",
                distanceKm = 2.8,
                workingHours = "09:00 ص - 12:00 م",
                phone = "+963118811223",
                whatsapp = "+963955001122",
                latitude = 33.4900,
                longitude = 36.3000,
                description = "أعرق وأفخر الحلويات الشامية بالسمن العربي الأصيل والفستق الحلبي الممتاز: بقلاوة، معمول، مبرومة، برازق، وتجهيز ضيافات للأعراس والمناسبات.",
                services = "حلويات بالسمن العربي, فستق حلبي فاخر, شحن وتغليف للمسافرين, كاتو ومناسبات, توصيل لكافة المناطق",
                currentOffer = "تغليف هدايا مجاني مع علب المشكل",
                isFeatured = true,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "إدارة دليلي"
            ),
            Place(
                name = "شركة النورس للشحن والتوصيل السريع",
                categoryId = "delivery",
                categoryName = "توصيل وشحن",
                rating = 4.7f,
                reviewCount = 76,
                address = "دمشق - المرجة - بناء البريد المركزي",
                area = "المرجة",
                city = "دمشق",
                distanceKm = 1.7,
                workingHours = "08:30 ص - 08:30 م",
                phone = "+963112244668",
                whatsapp = "+963966778899",
                latitude = 33.5120,
                longitude = 36.2970,
                description = "خدمات شحن ونقل طرود ووثائق سريعة لكافة المحافظات السورية والدول المجاورة، توصيل فوري للطلبات والمتاجر الإلكترونية مع تتبع الشحنة.",
                services = "شحن لكافة المحافظات, توصيل فوري للمتاجر, تتبع الشحنات, تغليف آمن للطرود, تحصيل أموال المتاجر",
                currentOffer = "خصم 15% على أول 3 شحنات للمتاجر الجديدة",
                isFeatured = false,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "إدارة النورس"
            ),
            Place(
                name = "فندق الياسمين التراثي",
                categoryId = "hotels",
                categoryName = "فنادق",
                rating = 4.9f,
                reviewCount = 88,
                address = "دمشق - دمشق القديمة - باب توما",
                area = "باب توما",
                city = "دمشق",
                distanceKm = 2.5,
                workingHours = "استقبال 24 ساعة",
                phone = "+963115433221",
                whatsapp = "+963944771122",
                latitude = 33.5110,
                longitude = 36.3150,
                description = "بيت دمشقي أثري تم تحويله إلى فندق بوتيك فخم، يقدم تجربة إقامة ساحرة مع بحرة ونوافير، غرف مجهزة بأعلى وسائل الراحة والضيافة الشامية الأصيلة.",
                services = "غرف وأجنحة تراثية, باحة أندلسية ونافورة, فطور شامي تقليدي, خدمة غرف 24 ساعة, جولات سياحية منظمة",
                currentOffer = "خصم 25% للحجوزات لأكثر من 3 ليالٍ",
                isFeatured = true,
                isOpenNow = true,
                isVerified = true,
                status = "APPROVED",
                submittedBy = "إدارة الفندق"
            )
        )

        placeDao.insertPlaces(placesList)

        // Seed initial reviews
        val initialReviews = listOf(
            Review(
                placeId = 1,
                userName = "سامر الخالدي",
                rating = 5,
                comment = "أفضل مطعم مشاوي في دمشق بلا منازع! الخدمة ممتازة واللحمة طازجة جداً والنظافة 10/10.",
                dateText = "منذ يومين"
            ),
            Review(
                placeId = 1,
                userName = "ريم النجار",
                rating = 5,
                comment = "المقبلات الشامية والفتوش رائعين، الجلسات مريحة وخدمة الاستقبال في غاية اللطف.",
                dateText = "منذ أسبوع"
            ),
            Review(
                placeId = 2,
                userName = "عمر الحكيم",
                rating = 5,
                comment = "القهوة عندهم تظبط المزاج، الوايفاي سريع جداً والمكان هادئ ومناسب للعمل أو الدراسة.",
                dateText = "منذ 3 أيام"
            ),
            Review(
                placeId = 3,
                userName = "طارق المصري",
                rating = 5,
                comment = "بدلت شاشة جهازي بـ 20 دقيقة وشغالة تمام مع كفالة، شغل نظيف واحترافي وأسعار منطقية.",
                dateText = "منذ 4 أيام"
            ),
            Review(
                placeId = 10,
                userName = "ميساء السعدي",
                rating = 5,
                comment = "الحلويات بالسمن العربي ريحتها وطعمها لا يوصف! التغليف مرتب جداً والضيافة فاخرة.",
                dateText = "منذ 5 أيام"
            )
        )
        reviewDao.insertReviews(initialReviews)

        // Seed initial notifications
        val initialNotifications = listOf(
            AppNotification(
                title = "مرحباً بك في دليلي",
                message = "تطبيقك الموثوق لاكتشاف المحلات والخدمات القريبة والتواصل السريع معها.",
                type = "SYSTEM"
            ),
            AppNotification(
                title = "عروض مميزة وحصرية",
                message = "اطلع على قسم العروض في الصفحة الرئيسية للاستفادة من تخفيضات المحلات الشريكة.",
                type = "OFFER"
            ),
            AppNotification(
                title = "أصحاب الأنشطة والخدمات",
                message = "يمكنك الآن إضافة محلك أو خدمتك مجاناً عبر نموذج «إضافة مكان جديد» من صفحة حسابي.",
                type = "PLACE"
            )
        )
        notificationDao.insertNotifications(initialNotifications)

        // Seed initial offers
        val initialOffers = listOf(
            AppOffer(
                placeId = 1,
                placeName = "مطعم الشرق الدمشقي",
                title = "وجبة المشاوي العائلية الكبرى",
                discountText = "خصم 20%",
                description = "كيلو ونصف مشاوي مشكلة مع المقبلات والسلطات والمشروبات بسعر خاص.",
                validUntil = "حتى نهاية الشهر"
            ),
            AppOffer(
                placeId = 6,
                placeName = "عيادات الشام لطب الأسنان",
                title = "تبييض الأسنان بالليزر",
                discountText = "خصم 30%",
                description = "جلسة تبييض كاملة مع تنظيف الرواسب والتلميع بأحدث جهاز أمريكي.",
                validUntil = "ساري هذا الأسبوع"
            ),
            AppOffer(
                placeId = 4,
                placeName = "تيك ماستر للكمبيوتر",
                title = "عرض حقيبة وماوس مجاناً",
                discountText = "هدية مجانية",
                description = "مع كل عملية شراء لأي لابتوب قيمنق أو لابتوب للدراسة والعمل.",
                validUntil = "حتى نفاد الكمية"
            )
        )
        offerDao.insertOffers(initialOffers)
    }
}

data class AdminStats(
    val totalUsers: Int,
    val totalPlaces: Int,
    val approvedPlaces: Int,
    val pendingPlaces: Int,
    val totalReviews: Int,
    val totalVisits: Int
)
