package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "places")
data class Place(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val categoryId: String,
    val categoryName: String,
    val rating: Float = 4.5f,
    val reviewCount: Int = 0,
    val address: String,
    val area: String,
    val city: String,
    val distanceKm: Double = 1.0,
    val workingHours: String,
    val phone: String,
    val whatsapp: String,
    val latitude: Double,
    val longitude: Double,
    val description: String,
    val services: String, // Comma-separated list of services
    val coverImage: String = "",
    val currentOffer: String? = null,
    val isFeatured: Boolean = false,
    val isOpenNow: Boolean = true,
    val isVerified: Boolean = true,
    val status: String = "APPROVED", // "APPROVED", "PENDING", "REJECTED"
    val submittedBy: String = "النظام",
    val createdAt: Long = System.currentTimeMillis(),
    val socialLink: String = ""
) {
    val servicesList: List<String>
        get() = if (services.isBlank()) emptyList() else services.split("،", ",").map { it.trim() }.filter { it.isNotEmpty() }

    val isPendingApproval: Boolean
        get() = status == "PENDING"
}
