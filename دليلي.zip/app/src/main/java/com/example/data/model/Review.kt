package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val placeId: Long,
    val userName: String,
    val rating: Int,
    val comment: String,
    val dateText: String,
    val createdAt: Long = System.currentTimeMillis()
)
