package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "offers")
data class AppOffer(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val placeId: Long,
    val placeName: String,
    val title: String,
    val discountText: String,
    val description: String,
    val validUntil: String,
    val isActive: Boolean = true
)
