package com.example.data.location

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class LocationType(val labelAr: String) {
    VILLAGE("ضيعة / قرية"),
    TOWN("بلدة"),
    CITY_DISTRICT("حي / منطقة"),
    CITY("مدينة")
}

data class VillageInfo(
    val nameAr: String,
    val governorateAr: String,
    val districtAr: String,
    val lat: Double,
    val lng: Double,
    val type: LocationType = LocationType.VILLAGE
)

object VillageDirectory {

    val allLocations: List<VillageInfo> = listOf(
        // === دمشق (أحياء ومناطق) ===
        VillageInfo("المزة", "دمشق", "دمشق الغربية", 33.5042, 36.2575, LocationType.CITY_DISTRICT),
        VillageInfo("أبورمانة", "دمشق", "وسط دمشق", 33.5186, 36.2828, LocationType.CITY_DISTRICT),
        VillageInfo("كفرسوسة", "دمشق", "جنوب دمشق", 33.4981, 36.2753, LocationType.CITY_DISTRICT),
        VillageInfo("المالكي", "دمشق", "وسط دمشق", 33.5222, 36.2789, LocationType.CITY_DISTRICT),
        VillageInfo("البرامكة", "دمشق", "وسط دمشق", 33.5089, 36.2892, LocationType.CITY_DISTRICT),
        VillageInfo("مشروع دمر", "دمشق", "شمال غرب دمشق", 33.5417, 36.2289, LocationType.CITY_DISTRICT),
        VillageInfo("الميدان", "دمشق", "جنوب دمشق", 33.4925, 36.2986, LocationType.CITY_DISTRICT),
        VillageInfo("باب توما", "دمشق", "دمشق القديمة", 33.5139, 36.3161, LocationType.CITY_DISTRICT),
        VillageInfo("القصاع", "دمشق", "شرق دمشق", 33.5181, 36.3197, LocationType.CITY_DISTRICT),
        VillageInfo("شارع بغداد", "دمشق", "وسط دمشق", 33.5233, 36.3056, LocationType.CITY_DISTRICT),
        VillageInfo("ركن الدين", "دمشق", "سفح قاسيون", 33.5389, 36.2958, LocationType.CITY_DISTRICT),
        VillageInfo("المهاجرين", "دمشق", "سفح قاسيون", 33.5283, 36.2694, LocationType.CITY_DISTRICT),
        VillageInfo("برزة", "دمشق", "شمال دمشق", 33.5583, 36.3194, LocationType.CITY_DISTRICT),
        VillageInfo("القابون", "دمشق", "شمال شرق دمشق", 33.5472, 36.3472, LocationType.CITY_DISTRICT),
        VillageInfo("الشاغور", "دمشق", "جنوب دمشق القديمة", 33.5056, 36.3111, LocationType.CITY_DISTRICT),

        // === ريف دمشق - ضياع وبلدات الغوطة الغربية وجبل الشيخ ===
        VillageInfo("صحنايا", "ريف دمشق", "داريا / صحنايا", 33.4358, 36.2411, LocationType.VILLAGE),
        VillageInfo("أشرفية صحنايا", "ريف دمشق", "صحنايا", 33.4219, 36.2306, LocationType.VILLAGE),
        VillageInfo("معضمية الشام", "ريف دمشق", "داريا", 33.4739, 36.2167, LocationType.TOWN),
        VillageInfo("داريا", "ريف دمشق", "الغوطة الغربية", 33.4583, 36.2389, LocationType.TOWN),
        VillageInfo("جديدة عرطوز", "ريف دمشق", "قطنا", 33.4472, 36.1778, LocationType.TOWN),
        VillageInfo("عرطوز", "ريف دمشق", "قطنا", 33.4389, 36.1667, LocationType.VILLAGE),
        VillageInfo("قطنا", "ريف دمشق", "جبل الشيخ", 33.4361, 36.0806, LocationType.TOWN),
        VillageInfo("خان الشيح", "ريف دمشق", "قطنا", 33.3667, 36.1167, LocationType.VILLAGE),
        VillageInfo("زاكية", "ريف دمشق", "الكسوة", 33.3167, 36.1500, LocationType.VILLAGE),
        VillageInfo("الكسوة", "ريف دمشق", "جنوب دمشق", 33.3556, 36.2444, LocationType.TOWN),
        VillageInfo("دير علي", "ريف دمشق", "الكسوة", 33.2833, 36.2833, LocationType.VILLAGE),
        VillageInfo("عرنة", "ريف دمشق", "جبل الشيخ", 33.3611, 35.8889, LocationType.VILLAGE),
        VillageInfo("حينة", "ريف دمشق", "جبل الشيخ", 33.3389, 35.9389, LocationType.VILLAGE),
        VillageInfo("كفر حور", "ريف دمشق", "جبل الشيخ", 33.3556, 36.0111, LocationType.VILLAGE),
        VillageInfo("بيت جن", "ريف دمشق", "جبل الشيخ", 33.3167, 35.8833, LocationType.VILLAGE),
        VillageInfo("قلعة جندل", "ريف دمشق", "جبل الشيخ", 33.3833, 35.9167, LocationType.VILLAGE),
        VillageInfo("بقعسم", "ريف دمشق", "جبل الشيخ", 33.3694, 35.9528, LocationType.VILLAGE),
        VillageInfo("سعسع", "ريف دمشق", "قطنا", 33.2889, 36.0278, LocationType.TOWN),

        // === ريف دمشق - وادي بردى والزبداني والقلمون ===
        VillageInfo("قدسيا", "ريف دمشق", "قدسيا", 33.5389, 36.2083, LocationType.TOWN),
        VillageInfo("الهامة", "ريف دمشق", "قدسيا", 33.5528, 36.2056, LocationType.VILLAGE),
        VillageInfo("جديدة الوادي", "ريف دمشق", "وادي بردى", 33.5667, 36.1833, LocationType.VILLAGE),
        VillageInfo("عين الفيجة", "ريف دمشق", "وادي بردى", 33.5861, 36.1528, LocationType.VILLAGE),
        VillageInfo("دير مقرن", "ريف دمشق", "وادي بردى", 33.6000, 36.1333, LocationType.VILLAGE),
        VillageInfo("كفير الزيت", "ريف دمشق", "وادي بردى", 33.6167, 36.1167, LocationType.VILLAGE),
        VillageInfo("سوق وادي بردى", "ريف دمشق", "وادي بردى", 33.6333, 36.1000, LocationType.VILLAGE),
        VillageInfo("مضايا", "ريف دمشق", "الزبداني", 33.6889, 36.1000, LocationType.TOWN),
        VillageInfo("بقين", "ريف دمشق", "الزبداني", 33.7000, 36.1056, LocationType.VILLAGE),
        VillageInfo("الزبداني", "ريف دمشق", "الزبداني", 33.7250, 36.0972, LocationType.TOWN),
        VillageInfo("بلودان", "ريف دمشق", "الزبداني", 33.7389, 36.1417, LocationType.TOWN),
        VillageInfo("سرغايا", "ريف دمشق", "الزبداني", 33.8056, 36.1472, LocationType.VILLAGE),
        VillageInfo("صيدنايا", "ريف دمشق", "التل", 33.6972, 36.3722, LocationType.TOWN),
        VillageInfo("معلولا", "ريف دمشق", "القطيفة", 33.8444, 36.5444, LocationType.VILLAGE),
        VillageInfo("منين", "ريف دمشق", "التل", 33.6278, 36.3194, LocationType.VILLAGE),
        VillageInfo("التل", "ريف دمشق", "التل", 33.6028, 36.3111, LocationType.TOWN),
        VillageInfo("حلبون", "ريف دمشق", "التل", 33.6556, 36.2694, LocationType.VILLAGE),
        VillageInfo("تلفيتا", "ريف دمشق", "التل", 33.7000, 36.3000, LocationType.VILLAGE),
        VillageInfo("رنكوس", "ريف دمشق", "التل", 33.7750, 36.3889, LocationType.VILLAGE),
        VillageInfo("القطيفة", "ريف دمشق", "القطيفة", 33.7389, 36.6000, LocationType.TOWN),
        VillageInfo("يبرود", "ريف دمشق", "يبرود", 33.9667, 36.6583, LocationType.TOWN),
        VillageInfo("النبك", "ريف دمشق", "النبك", 34.0250, 36.7278, LocationType.TOWN),
        VillageInfo("دير عطية", "ريف دمشق", "النبك", 34.0917, 36.7694, LocationType.TOWN),
        VillageInfo("قارة", "ريف دمشق", "النبك", 34.1556, 36.7444, LocationType.TOWN),

        // === ريف دمشق - الغوطة الشرقية والجنوبية ===
        VillageInfo("جرمانا", "ريف دمشق", "الغوطة الشرقية", 33.4861, 36.3472, LocationType.TOWN),
        VillageInfo("السيدة زينب", "ريف دمشق", "جنوب دمشق", 33.4444, 36.3417, LocationType.TOWN),
        VillageInfo("ببيلا", "ريف دمشق", "جنوب دمشق", 33.4722, 36.3194, LocationType.VILLAGE),
        VillageInfo("يلدا", "ريف دمشق", "جنوب دمشق", 33.4639, 36.3083, LocationType.VILLAGE),
        VillageInfo("بيت سحم", "ريف دمشق", "طريق المطار", 33.4583, 36.3306, LocationType.VILLAGE),
        VillageInfo("دوما", "ريف دمشق", "الغوطة الشرقية", 33.5722, 36.4028, LocationType.TOWN),
        VillageInfo("حرستا", "ريف دمشق", "الغوطة الشرقية", 33.5583, 36.3639, LocationType.TOWN),
        VillageInfo("كفر بطنا", "ريف دمشق", "الغوطة الشرقية", 33.5139, 36.3639, LocationType.VILLAGE),
        VillageInfo("سقبا", "ريف دمشق", "الغوطة الشرقية", 33.5194, 36.3750, LocationType.VILLAGE),
        VillageInfo("المليحة", "ريف دمشق", "الغوطة الشرقية", 33.4861, 36.3750, LocationType.VILLAGE),
        VillageInfo("عربين", "ريف دمشق", "الغوطة الشرقية", 33.5361, 36.3639, LocationType.VILLAGE),
        VillageInfo("زملكا", "ريف دمشق", "الغوطة الشرقية", 33.5278, 36.3472, LocationType.VILLAGE),

        // === اللاذقية والساحل وقراها ===
        VillageInfo("الزراعة", "اللاذقية", "اللاذقية المدينة", 35.5317, 35.7925, LocationType.CITY_DISTRICT),
        VillageInfo("الصليبة", "اللاذقية", "اللاذقية القديمة", 35.5200, 35.7800, LocationType.CITY_DISTRICT),
        VillageInfo("مشروع الصليبة", "اللاذقية", "وسط المدينة", 35.5250, 35.7850, LocationType.CITY_DISTRICT),
        VillageInfo("الكورنيش الغربي", "اللاذقية", "شاطئ البحر", 35.5167, 35.7667, LocationType.CITY_DISTRICT),
        VillageInfo("الأمريكان", "اللاذقية", "اللاذقية المدينة", 35.5283, 35.7789, LocationType.CITY_DISTRICT),
        VillageInfo("جبلة", "اللاذقية", "جبلة", 35.3611, 35.9278, LocationType.TOWN),
        VillageInfo("القرداحة", "اللاذقية", "القرداحة", 35.4583, 36.0611, LocationType.TOWN),
        VillageInfo("الحفة", "اللاذقية", "الحفة", 35.6028, 36.0278, LocationType.TOWN),
        VillageInfo("صلنفة", "اللاذقية", "الحفة / الجبل", 35.5972, 36.1972, LocationType.TOWN),
        VillageInfo("كسب", "اللاذقية", "شمال اللاذقية", 35.9250, 35.9861, LocationType.VILLAGE),
        VillageInfo("مشقيتا", "اللاذقية", "بحيرات مشقيتا", 35.6944, 35.8889, LocationType.VILLAGE),
        VillageInfo("برج إسلام", "اللاذقية", "الشاطئ الأزرق", 35.6444, 35.7806, LocationType.VILLAGE),
        VillageInfo("وادي قنديل", "اللاذقية", "الشاطئ الشمالي", 35.7333, 35.8333, LocationType.VILLAGE),
        VillageInfo("كرسانا", "اللاذقية", "شمال المدينة", 35.5944, 35.8167, LocationType.VILLAGE),
        VillageInfo("البهلولية", "اللاذقية", "ريف اللاذقية", 35.6389, 36.0028, LocationType.VILLAGE),
        VillageInfo("اسطامو", "اللاذقية", "القرداحة", 35.4333, 35.9167, LocationType.VILLAGE),

        // === طرطوس وقراها وبلداتها ===
        VillageInfo("الكورنيش البحري", "طرطوس", "طرطوس المدينة", 34.8889, 35.8833, LocationType.CITY_DISTRICT),
        VillageInfo("المشبكة", "طرطوس", "طرطوس المدينة", 34.8972, 35.8944, LocationType.CITY_DISTRICT),
        VillageInfo("الثورة", "طرطوس", "طرطوس المدينة", 34.8917, 35.8972, LocationType.CITY_DISTRICT),
        VillageInfo("بانياس", "طرطوس", "بانياس", 35.1833, 35.9389, LocationType.TOWN),
        VillageInfo("صافيتا", "طرطوس", "صافيتا", 34.8222, 36.1194, LocationType.TOWN),
        VillageInfo("الدريكيش", "طرطوس", "الدريكيش", 34.8972, 36.1389, LocationType.TOWN),
        VillageInfo("الشيخ بدر", "طرطوس", "الشيخ بدر", 34.9861, 36.0889, LocationType.TOWN),
        VillageInfo("القدموس", "طرطوس", "القدموس", 35.1000, 36.1611, LocationType.TOWN),
        VillageInfo("مشتى الحلو", "طرطوس", "صافيتا / المشتى", 34.8917, 36.2361, LocationType.VILLAGE),
        VillageInfo("الكفرون", "طرطوس", "صافيتا", 34.8833, 36.2167, LocationType.VILLAGE),
        VillageInfo("الروضة", "طرطوس", "بانياس", 35.1333, 35.9667, LocationType.VILLAGE),
        VillageInfo("خربة المعزة", "طرطوس", "سهل عكار", 34.7833, 35.9667, LocationType.VILLAGE),
        VillageInfo("عمريت", "طرطوس", "جنوب طرطوس", 34.8389, 35.8750, LocationType.VILLAGE),

        // === حمص وقراها وبلداتها ===
        VillageInfo("الإنشاءات", "حمص", "حمص المدينة", 34.7167, 36.6889, LocationType.CITY_DISTRICT),
        VillageInfo("الحمراء", "حمص", "حمص المدينة", 34.7250, 36.7028, LocationType.CITY_DISTRICT),
        VillageInfo("الدبلان", "حمص", "وسط المدينة", 34.7306, 36.7111, LocationType.CITY_DISTRICT),
        VillageInfo("عكرمة", "حمص", "جنوب المدينة", 34.7083, 36.7167, LocationType.CITY_DISTRICT),
        VillageInfo("الوعر", "حمص", "غرب المدينة", 34.7444, 36.6694, LocationType.CITY_DISTRICT),
        VillageInfo("وادي النصارى / الحواش", "حمص", "تلكلخ", 34.7750, 36.3111, LocationType.VILLAGE),
        VillageInfo("مرمريتا", "حمص", "وادي النصارى", 34.7917, 36.2583, LocationType.VILLAGE),
        VillageInfo("حب نمرة", "حمص", "وادي النصارى", 34.8056, 36.2833, LocationType.VILLAGE),
        VillageInfo("كفربهم", "حمص / حماة", "الريف الغربي", 35.0500, 36.7000, LocationType.VILLAGE),
        VillageInfo("تلكلخ", "حمص", "تلكلخ", 34.6611, 36.2556, LocationType.TOWN),
        VillageInfo("القصير", "حمص", "القصير", 34.5083, 36.5778, LocationType.TOWN),
        VillageInfo("الرستن", "حمص", "الرستن", 34.9278, 36.7333, LocationType.TOWN),
        VillageInfo("تلبيسة", "حمص", "حمص الشمالي", 34.8417, 36.7306, LocationType.TOWN),
        VillageInfo("تدمر", "حمص", "البادية", 34.5600, 38.2817, LocationType.CITY),
        VillageInfo("شين", "حمص", "جبل الحلو", 34.7833, 36.4500, LocationType.VILLAGE),
        VillageInfo("قطينة", "حمص", "بحيرة قطينة", 34.6444, 36.6167, LocationType.VILLAGE),

        // === حماة وقراها وبلداتها ===
        VillageInfo("الحاضر", "حماة", "حماة القديمة", 35.1389, 36.7556, LocationType.CITY_DISTRICT),
        VillageInfo("الدباغة", "حماة", "وسط المدينة", 35.1333, 36.7500, LocationType.CITY_DISTRICT),
        VillageInfo("الشريعة", "حماة", "حماة المدينة", 35.1472, 36.7389, LocationType.CITY_DISTRICT),
        VillageInfo("القصور", "حماة", "شمال المدينة", 35.1556, 36.7611, LocationType.CITY_DISTRICT),
        VillageInfo("مصياف", "حماة", "مصياف", 35.0653, 36.3419, LocationType.TOWN),
        VillageInfo("محردة", "حماة", "محردة", 35.2500, 36.5750, LocationType.TOWN),
        VillageInfo("السقيلبية", "حماة", "الغاب", 35.3778, 36.4028, LocationType.TOWN),
        VillageInfo("سلمية", "حماة", "سلمية", 35.0111, 37.0528, LocationType.TOWN),
        VillageInfo("صوران", "حماة", "شمال حماة", 35.2889, 36.7500, LocationType.TOWN),
        VillageInfo("طيبة الإمام", "حماة", "شمال حماة", 35.2667, 36.7111, LocationType.TOWN),
        VillageInfo("كفرزيتا", "حماة", "ريف حماة الشمالي", 35.3750, 36.6000, LocationType.TOWN),
        VillageInfo("وادي العيون", "حماة", "مصياف", 35.0333, 36.2167, LocationType.VILLAGE),
        VillageInfo("سلحب", "حماة", "سهل الغاب", 35.2833, 36.3833, LocationType.TOWN),

        // === حلب وقراها وأريافها ===
        VillageInfo("الشهباء", "حلب", "حلب الغربية", 36.2222, 37.1278, LocationType.CITY_DISTRICT),
        VillageInfo("الفرقان", "حلب", "جامعة حلب", 36.2056, 37.1167, LocationType.CITY_DISTRICT),
        VillageInfo("الموغامبو", "حلب", "شمال حلب", 36.2278, 37.1333, LocationType.CITY_DISTRICT),
        VillageInfo("العزيزية", "حلب", "وسط حلب", 36.2139, 37.1500, LocationType.CITY_DISTRICT),
        VillageInfo("السليمانية", "حلب", "وسط حلب", 36.2183, 37.1567, LocationType.CITY_DISTRICT),
        VillageInfo("حلب الجديدة", "حلب", "غرب حلب", 36.2111, 37.0889, LocationType.CITY_DISTRICT),
        VillageInfo("عفرين", "حلب", "عفرين", 36.5111, 36.8694, LocationType.TOWN),
        VillageInfo("إعزاز", "حلب", "شمال حلب", 36.5861, 37.0444, LocationType.TOWN),
        VillageInfo("منبج", "حلب", "شرق حلب", 36.5281, 37.9547, LocationType.CITY),
        VillageInfo("الباب", "حلب", "شرق حلب", 36.3700, 37.5158, LocationType.TOWN),
        VillageInfo("نبل", "حلب", "شمال غرب حلب", 36.3778, 37.0083, LocationType.VILLAGE),
        VillageInfo("الزهراء", "حلب", "شمال غرب حلب", 36.3639, 36.9944, LocationType.VILLAGE),
        VillageInfo("تل رفعت", "حلب", "شمال حلب", 36.4722, 37.0944, LocationType.VILLAGE),
        VillageInfo("السفيرة", "حلب", "جنوب شرق حلب", 36.0778, 37.3722, LocationType.TOWN),
        VillageInfo("دير حافر", "حلب", "شرق حلب", 36.1556, 37.7056, LocationType.TOWN),
        VillageInfo("الأتارب", "حلب", "ريف حلب الغربي", 36.1417, 36.8222, LocationType.TOWN),
        VillageInfo("دارة عزة", "حلب", "جبل سمعان", 36.2806, 36.8528, LocationType.TOWN),
        VillageInfo("جنديرس", "حلب", "عفرين", 36.3972, 36.6889, LocationType.TOWN),

        // === درعا وقراها وبلداتها ===
        VillageInfo("درعا المحطة", "درعا", "درعا المدينة", 32.6256, 36.1056, LocationType.CITY_DISTRICT),
        VillageInfo("درعا البلد", "درعا", "درعا القديمة", 32.6111, 36.1000, LocationType.CITY_DISTRICT),
        VillageInfo("الصنمين", "درعا", "شمال درعا", 33.0722, 36.1833, LocationType.TOWN),
        VillageInfo("إزرع", "درعا", "وسط درعا", 32.8694, 36.2528, LocationType.TOWN),
        VillageInfo("الشيخ مسكين", "درعا", "حوران", 32.8306, 36.1583, LocationType.TOWN),
        VillageInfo("نوى", "درعا", "حوران الغربية", 32.8889, 36.0417, LocationType.TOWN),
        VillageInfo("طفس", "درعا", "حوران", 32.7444, 36.0694, LocationType.TOWN),
        VillageInfo("بصرى الشام", "درعا", "بصرى", 32.5194, 36.4806, LocationType.TOWN),
        VillageInfo("خربة غزالة", "درعا", "الأوتوستراد الدولي", 32.7444, 36.2167, LocationType.VILLAGE),
        VillageInfo("داعل", "درعا", "وسط حوران", 32.7528, 36.1444, LocationType.TOWN),
        VillageInfo("جاسم", "درعا", "حوران الشمالية", 32.9611, 36.0583, LocationType.TOWN),
        VillageInfo("المزيريب", "درعا", "بحيرة المزيريب", 32.7056, 36.0278, LocationType.VILLAGE),
        VillageInfo("تسيل", "درعا", "حوض اليرموك", 32.8333, 35.9667, LocationType.VILLAGE),

        // === السويداء وقراها وجبل العرب ===
        VillageInfo("السويداء المدينة", "السويداء", "السويداء", 32.7089, 36.5694, LocationType.CITY),
        VillageInfo("شهبا", "السويداء", "شمال السويداء", 32.8556, 36.6278, LocationType.TOWN),
        VillageInfo("صلخد", "السويداء", "جنوب السويداء", 32.4944, 36.7111, LocationType.TOWN),
        VillageInfo("القريا", "السويداء", "جنوب غرب السويداء", 32.5444, 36.5944, LocationType.VILLAGE),
        VillageInfo("المزرعة", "السويداء", "غرب السويداء", 32.7167, 36.4667, LocationType.VILLAGE),
        VillageInfo("قنوات", "السويداء", "جبل العرب", 32.7556, 36.6167, LocationType.VILLAGE),
        VillageInfo("الكفر", "السويداء", "جنوب السويداء", 32.6167, 36.6333, LocationType.VILLAGE),
        VillageInfo("عريقة", "السويداء", "اللجاة", 32.8889, 36.4833, LocationType.VILLAGE),
        VillageInfo("شقا", "السويداء", "شمال شرق السويداء", 32.9056, 36.7000, LocationType.VILLAGE),
        VillageInfo("ملح", "السويداء", "شرق السويداء", 32.5167, 36.8333, LocationType.VILLAGE),
        VillageInfo("سليم", "السويداء", "شمال المدينة", 32.7833, 36.5833, LocationType.VILLAGE),

        // === القنيطرة والجولان ===
        VillageInfo("خان أرنبة", "القنيطرة", "القنيطرة", 33.1778, 35.9111, LocationType.TOWN),
        VillageInfo("مدينة البعث", "القنيطرة", "القنيطرة", 33.1611, 35.8889, LocationType.TOWN),
        VillageInfo("حضر", "القنيطرة", "سفح جبل الشيخ", 33.2556, 35.8889, LocationType.VILLAGE),
        VillageInfo("جبا", "القنيطرة", "ريف القنيطرة", 33.1833, 35.9500, LocationType.VILLAGE),
        VillageInfo("نبع الصخر", "القنيطرة", "جنوب القنيطرة", 33.0667, 35.9167, LocationType.VILLAGE),
        VillageInfo("بريقة", "القنيطرة", "الجولان", 33.0500, 35.8833, LocationType.VILLAGE),

        // === إدلب وقراها وبلداتها ===
        VillageInfo("إدلب المدينة", "إدلب", "إدلب", 35.9306, 36.6339, LocationType.CITY),
        VillageInfo("معرة النعمان", "إدلب", "جنوب إدلب", 35.6456, 36.6778, LocationType.TOWN),
        VillageInfo("أريحا", "إدلب", "جبل الأربعين", 35.8139, 36.6111, LocationType.TOWN),
        VillageInfo("سرمدا", "إدلب", "شمال إدلب", 36.1833, 36.7167, LocationType.TOWN),
        VillageInfo("الدانا", "إدلب", "شمال إدلب", 36.2167, 36.7667, LocationType.TOWN),
        VillageInfo("بنش", "إدلب", "شرق إدلب", 35.9611, 36.7111, LocationType.TOWN),
        VillageInfo("جسر الشغور", "إدلب", "غرب إدلب", 35.8139, 36.3194, LocationType.TOWN),
        VillageInfo("سلقين", "إدلب", "حوض العاصي", 36.1389, 36.4500, LocationType.TOWN),
        VillageInfo("حارم", "إدلب", "شمال غرب إدلب", 36.2083, 36.5194, LocationType.TOWN),
        VillageInfo("سراقب", "إدلب", "تقاطع الطرق الدولي", 35.8583, 36.8083, LocationType.TOWN),

        // === الحسكة والقامشلي ودير الزور والرقة ===
        VillageInfo("الحسكة المدينة", "الحسكة", "الحسكة", 36.5050, 40.7450, LocationType.CITY),
        VillageInfo("القامشلي", "الحسكة", "القامشلي", 36.8400, 41.2200, LocationType.CITY),
        VillageInfo("عامودا", "الحسكة", "شمال الحسكة", 37.1000, 40.9167, LocationType.TOWN),
        VillageInfo("المالكية (ديريك)", "الحسكة", "أقصى الشمال الشرقي", 37.1750, 42.1389, LocationType.TOWN),
        VillageInfo("رأس العين", "الحسكة", "الخابور", 36.8500, 40.0667, LocationType.TOWN),
        VillageInfo("دير الزور المدينة", "دير الزور", "دير الزور", 35.3333, 40.1500, LocationType.CITY),
        VillageInfo("الميادين", "دير الزور", "وادي الفرات", 35.0167, 40.4500, LocationType.TOWN),
        VillageInfo("البوكمال", "دير الزور", "الحدود الفراتية", 34.4500, 40.9167, LocationType.TOWN),
        VillageInfo("الرقة المدينة", "الرقة", "الرقة", 35.9500, 39.0167, LocationType.CITY),
        VillageInfo("الطبقة (الثورة)", "الرقة", "سد الفرات", 35.8333, 38.5500, LocationType.TOWN)
    )

    /**
     * Finds the nearest registered village/town/district using Haversine calculation
     */
    fun findNearestVillage(userLat: Double, userLng: Double): Pair<VillageInfo, Double> {
        var closest = allLocations.first()
        var minDistance = Double.MAX_VALUE

        for (loc in allLocations) {
            val dist = calculateDistanceKm(userLat, userLng, loc.lat, loc.lng)
            if (dist < minDistance) {
                minDistance = dist
                closest = loc
            }
        }
        return Pair(closest, minDistance)
    }

    /**
     * Accurate Great-Circle Distance (Haversine formula in Kilometers)
     */
    fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadiusKm = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadiusKm * c
    }

    /**
     * Search locations matching query (name, governorate, or district)
     */
    fun searchLocations(query: String): List<VillageInfo> {
        if (query.isBlank()) return allLocations
        val q = query.trim().lowercase()
        return allLocations.filter {
            it.nameAr.lowercase().contains(q) ||
            it.governorateAr.lowercase().contains(q) ||
            it.districtAr.lowercase().contains(q) ||
            it.type.labelAr.lowercase().contains(q)
        }
    }

    /**
     * Get distinct list of governorates
     */
    fun getGovernorates(): List<String> {
        return allLocations.map { it.governorateAr }.distinct()
    }

    /**
     * Get villages for specific governorate
     */
    fun getVillagesForGovernorate(governorate: String): List<VillageInfo> {
        return allLocations.filter { it.governorateAr == governorate }
    }
}
