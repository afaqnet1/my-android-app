package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val email: String,
    val fullName: String,
    val isVerified: Boolean = true,
    val verifiedBy: String = "Shukri",
    val phone: String? = null,
    val avatarUrl: String? = null,
    val joinedAt: Long = System.currentTimeMillis()
)
