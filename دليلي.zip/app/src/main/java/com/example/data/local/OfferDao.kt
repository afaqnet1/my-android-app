package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.AppOffer
import kotlinx.coroutines.flow.Flow

@Dao
interface OfferDao {
    @Query("SELECT * FROM offers WHERE isActive = 1 ORDER BY id DESC")
    fun getActiveOffers(): Flow<List<AppOffer>>

    @Query("SELECT * FROM offers ORDER BY id DESC")
    fun getAllOffersAdmin(): Flow<List<AppOffer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffer(offer: AppOffer): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffers(offers: List<AppOffer>)

    @Query("DELETE FROM offers WHERE id = :id")
    suspend fun deleteOffer(id: Long)
}
