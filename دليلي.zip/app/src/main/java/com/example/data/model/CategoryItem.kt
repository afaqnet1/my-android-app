package com.example.data.model

data class CategoryItem(
    val id: String,
    val nameAr: String,
    val iconType: String,
    val count: Int = 0,
    val description: String = ""
)
