package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class Favorite(
    @PrimaryKey
    val placeId: Long,
    val addedAt: Long = System.currentTimeMillis()
)
