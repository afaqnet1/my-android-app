package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Place
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaceDao {
    @Query("SELECT * FROM places WHERE status = 'APPROVED' ORDER BY id DESC")
    fun getAllApprovedPlaces(): Flow<List<Place>>

    @Query("SELECT * FROM places ORDER BY id DESC")
    fun getAllPlacesAdmin(): Flow<List<Place>>

    @Query("SELECT * FROM places WHERE status = 'PENDING' ORDER BY createdAt DESC")
    fun getPendingPlaces(): Flow<List<Place>>

    @Query("SELECT * FROM places WHERE id = :id")
    fun getPlaceById(id: Long): Flow<Place?>

    @Query("SELECT * FROM places WHERE id = :id")
    suspend fun getPlaceByIdDirect(id: Long): Place?

    @Query("SELECT * FROM places WHERE status = 'APPROVED' AND categoryId = :categoryId")
    fun getPlacesByCategory(categoryId: String): Flow<List<Place>>

    @Query("SELECT * FROM places WHERE status = 'APPROVED' AND isFeatured = 1")
    fun getFeaturedPlaces(): Flow<List<Place>>

    @Query("SELECT * FROM places WHERE status = 'APPROVED' AND currentOffer IS NOT NULL")
    fun getPlacesWithOffers(): Flow<List<Place>>

    @Query("SELECT * FROM places WHERE submittedBy = :username ORDER BY createdAt DESC")
    fun getPlacesByUser(username: String): Flow<List<Place>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlace(place: Place): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaces(places: List<Place>)

    @Update
    suspend fun updatePlace(place: Place)

    @Query("UPDATE places SET status = :status WHERE id = :placeId")
    suspend fun updatePlaceStatus(placeId: Long, status: String)

    @Query("UPDATE places SET rating = :rating, reviewCount = :reviewCount WHERE id = :placeId")
    suspend fun updatePlaceRating(placeId: Long, rating: Float, reviewCount: Int)

    @Query("DELETE FROM places WHERE id = :id")
    suspend fun deletePlace(id: Long)

    @Query("SELECT COUNT(*) FROM places")
    suspend fun getTotalCount(): Int

    @Query("SELECT COUNT(*) FROM places WHERE status = 'APPROVED'")
    suspend fun getApprovedCount(): Int

    @Query("SELECT COUNT(*) FROM places WHERE status = 'PENDING'")
    suspend fun getPendingCount(): Int
}
