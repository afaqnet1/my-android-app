package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val message: String,
    val type: String, // "OFFER", "PLACE", "SYSTEM", "UPDATE"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val placeId: Long? = null
) {
    val actionPlaceId: Long? get() = placeId
    val timeAgo: String
        get() {
            val diffMinutes = (System.currentTimeMillis() - timestamp) / (1000 * 60)
            return when {
                diffMinutes < 1 -> "الآن"
                diffMinutes < 60 -> "منذ $diffMinutes د"
                diffMinutes < 1440 -> "منذ ${diffMinutes / 60} س"
                else -> "منذ ${diffMinutes / 1440} ي"
            }
        }
}
