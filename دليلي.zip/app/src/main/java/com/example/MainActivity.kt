package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.DaliliTopBar
import com.example.ui.components.GmailAuthDialog
import com.example.ui.components.LocationSelectorDialog
import com.example.ui.screens.AddPlaceScreen
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.ExploreScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.PlaceDetailScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.DaliliTheme
import com.example.ui.theme.DaliliYellowPrimary
import com.example.ui.viewmodel.DaliliViewModel
import com.example.ui.viewmodel.ScreenTab

class MainActivity : ComponentActivity() {
    private val viewModel: DaliliViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

            DaliliTheme(darkTheme = isDarkTheme) {
                // RTL Arabic Layout Direction
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    DaliliApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun DaliliApp(viewModel: DaliliViewModel) {
    val isSplashFinished by viewModel.isSplashFinished.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedPlaceDetailId by viewModel.selectedPlaceDetailId.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val unreadNotificationsCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()
    val currentCity by viewModel.currentCity.collectAsStateWithLifecycle()
    val currentArea by viewModel.currentArea.collectAsStateWithLifecycle()
    val currentLocationType by viewModel.currentLocationType.collectAsStateWithLifecycle()
    val isGpsActive by viewModel.isGpsActive.collectAsStateWithLifecycle()
    val isDetectingLocation by viewModel.isDetectingLocation.collectAsStateWithLifecycle()
    val gpsAccuracyStatus by viewModel.gpsAccuracyStatus.collectAsStateWithLifecycle()
    val isAuthDialogOpen by viewModel.isAuthDialogOpen.collectAsStateWithLifecycle()

    var showLocationDialog by remember { mutableStateOf(false) }

    // Location Permission Request
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            viewModel.detectPrecisionGps()
        }
    }

    if (!isSplashFinished) {
        SplashScreen(
            onSplashFinished = { viewModel.completeSplash() }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                // Show DaliliTopBar on root tabs (Home, Explore, Map, Favorites, Profile)
                if (selectedPlaceDetailId == null &&
                    currentTab != ScreenTab.ADD_PLACE &&
                    currentTab != ScreenTab.ADMIN &&
                    currentTab != ScreenTab.NOTIFICATIONS
                ) {
                    DaliliTopBar(
                        city = currentCity,
                        area = currentArea,
                        locationType = currentLocationType,
                        isGpsActive = isGpsActive,
                        isDarkTheme = isDarkTheme,
                        unreadNotificationsCount = unreadNotificationsCount,
                        onLocationClick = { showLocationDialog = true },
                        onNotificationsClick = { viewModel.setTab(ScreenTab.NOTIFICATIONS) },
                        onToggleThemeClick = { viewModel.toggleTheme() }
                    )
                }
            },
            bottomBar = {
                // Show bottom navigation bar only when not in full screens like PlaceDetail, AddPlace, Admin
                if (selectedPlaceDetailId == null &&
                    currentTab != ScreenTab.ADD_PLACE &&
                    currentTab != ScreenTab.ADMIN &&
                    currentTab != ScreenTab.NOTIFICATIONS
                ) {
                    DaliliBottomNavigationBar(
                        currentTab = currentTab,
                        onTabSelected = { tab -> viewModel.setTab(tab) }
                    )
                }
            },
            floatingActionButton = {
                if (selectedPlaceDetailId == null &&
                    currentTab != ScreenTab.ADD_PLACE &&
                    currentTab != ScreenTab.ADMIN &&
                    currentTab != ScreenTab.NOTIFICATIONS
                ) {
                    FloatingActionButton(
                        onClick = { viewModel.setTab(ScreenTab.ADD_PLACE) },
                        containerColor = DaliliYellowPrimary,
                        contentColor = Color(0xFF141208),
                        shape = CircleShape,
                        modifier = Modifier
                            .testTag("floating_add_place_btn")
                            .shadow(8.dp, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "إضافة محل أو خدمة",
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Route between views
                if (selectedPlaceDetailId != null) {
                    PlaceDetailScreen(
                        placeId = selectedPlaceDetailId!!,
                        viewModel = viewModel
                    )
                } else {
                    when (currentTab) {
                        ScreenTab.HOME -> {
                            HomeScreen(
                                viewModel = viewModel,
                                onOpenLocationDialog = { showLocationDialog = true }
                            )
                        }
                        ScreenTab.EXPLORE -> {
                            ExploreScreen(
                                viewModel = viewModel
                            )
                        }
                        ScreenTab.MAP -> {
                            MapScreen(
                                viewModel = viewModel,
                                onOpenLocationDialog = { showLocationDialog = true }
                            )
                        }
                        ScreenTab.FAVORITES -> {
                            FavoritesScreen(
                                viewModel = viewModel
                            )
                        }
                        ScreenTab.PROFILE -> {
                            ProfileScreen(
                                viewModel = viewModel,
                                onOpenLocationDialog = { showLocationDialog = true }
                            )
                        }
                        ScreenTab.ADD_PLACE -> {
                            AddPlaceScreen(
                                viewModel = viewModel
                            )
                        }
                        ScreenTab.ADMIN -> {
                            AdminDashboardScreen(
                                viewModel = viewModel
                            )
                        }
                        ScreenTab.NOTIFICATIONS -> {
                            NotificationsScreen(
                                viewModel = viewModel
                            )
                        }
                    }
                }
            }
        }

        // Luxury Location & Village Selector Modal Dialog
        if (showLocationDialog) {
            LocationSelectorDialog(
                currentCity = currentCity,
                currentArea = currentArea,
                isGpsActive = isGpsActive,
                isDetectingLocation = isDetectingLocation,
                gpsAccuracyStatus = gpsAccuracyStatus,
                onDetectGps = {
                    locationPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                },
                onSelectVillage = { village ->
                    viewModel.selectVillage(village)
                },
                onSelectCustomLocation = { city, area ->
                    viewModel.setLocation(city, area, isGps = false)
                },
                onDismiss = { showLocationDialog = false }
            )
        }

        // Luxury Gmail & Shukri Authentication Modal Dialog
        if (isAuthDialogOpen) {
            GmailAuthDialog(
                viewModel = viewModel,
                onDismissRequest = { viewModel.closeAuthDialog() }
            )
        }
    }
}

@Composable
fun DaliliBottomNavigationBar(
    currentTab: ScreenTab,
    onTabSelected: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .testTag("dalili_bottom_nav_bar"),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(0.5.dp, DaliliYellowPrimary.copy(alpha = 0.2f)),
        tonalElevation = 8.dp
    ) {
        NavigationBar(
            modifier = Modifier.fillMaxWidth(),
            containerColor = Color.Transparent,
            tonalElevation = 0.dp
        ) {
            val navItems = listOf(
                NavItem(ScreenTab.HOME, "الرئيسية", Icons.Filled.Home, Icons.Outlined.Home, "nav_home_tab"),
                NavItem(ScreenTab.EXPLORE, "استكشف", Icons.Filled.Explore, Icons.Outlined.Explore, "nav_explore_tab"),
                NavItem(ScreenTab.MAP, "الخريطة", Icons.Filled.Map, Icons.Outlined.Map, "nav_map_tab"),
                NavItem(ScreenTab.FAVORITES, "المفضلة", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder, "nav_favorites_tab"),
                NavItem(ScreenTab.PROFILE, "حسابي", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile_tab")
            )

            navItems.forEach { item ->
                val isSelected = currentTab == item.tab
                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onTabSelected(item.tab) },
                    icon = {
                        Icon(
                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = item.label,
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = item.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                fontSize = 11.sp
                            )
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF141208),
                        selectedTextColor = DaliliYellowPrimary,
                        indicatorColor = DaliliYellowPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag(item.testTag)
                )
            }
        }
    }
}

private data class NavItem(
    val tab: ScreenTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)
